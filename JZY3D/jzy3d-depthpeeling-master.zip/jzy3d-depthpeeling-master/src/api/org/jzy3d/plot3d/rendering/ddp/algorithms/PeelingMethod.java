package org.jzy3d.plot3d.rendering.ddp.algorithms;

public enum PeelingMethod {
    DUAL_PEELING_MODE,
    F2B_PEELING_MODE,
    WEIGHTED_AVERAGE_MODE,
    WEIGHTED_SUM_MODE;
}
