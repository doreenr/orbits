jzy3d-depthpeeling
==================

This project is part of a <a href="https://github.com/jzy3d/jzy3d-master">multi-modules project</a>

An extension of Jzy3d allowing to deploy depth peeling based charts for scene graph order independent transparency.

See http://www.jzy3d.org/plugins-depthpeeling.php
