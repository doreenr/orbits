import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Polygon;

public class pentagon_main extends JFrame implements ActionListener {
	private JButton On= new JButton("On");
	private JButton Off = new JButton("Off");
        private JPanel a = new JPanel();
	private pentagon p = new pentagon(5,50);
	
public pentagonmain() {
		add(a,BorderLayout.SOUTH);
		a.add(On); a.add(Off); 
		On.addActionListener(this);
		Off.addActionListener(this);
		setSize(200,180);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setTitle("Pentagon");
	}
	
	
public static void main(String[] arg) {
		pentagonmain pd = new pentagonmain();
	}
}
