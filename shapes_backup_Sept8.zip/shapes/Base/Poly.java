import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.util.*;

public class Poly extends Applet 
    implements WindowListener {

    DrawCanvas theCanvas;
    Toolbar theToolbar;
    Controls theControls;
    static Frame theApp; // used only in Application mode

    public Toolbar getToolbar() { return theToolbar; }
    public DrawCanvas getDrawCanvas() { return theCanvas; }
    public Controls getControls() { return theControls; }

    public void init() {
      setBackground(Color.gray);
      theControls = new Controls(this);
      theCanvas = new DrawCanvas(this);
      theToolbar = new Toolbar(this);
      theToolbar.setSize(200,150);
      setLayout(new BorderLayout());
      add(theCanvas, BorderLayout.CENTER);
      add(theToolbar, BorderLayout.NORTH);
      add(theControls, BorderLayout.WEST);
    }

    public static void main(String [] args) {
	Poly aPD = new Poly();
        theApp = new Frame();
        theApp.setSize(800,600);
        theApp.setLayout(new BorderLayout());
        aPD.init();
        theApp.addWindowListener(aPD);
        theApp.add(aPD, BorderLayout.CENTER);
        theApp.show();
    }

    public void windowClosing(WindowEvent e) {
        System.exit(0);
    }
    public void windowClosed(WindowEvent e) {
        System.exit(0);
    }
    public void windowOpened(WindowEvent e) {}
    public void windowIconified(WindowEvent e) {}
    public void windowDeiconified(WindowEvent e) {}
    public void windowActivated(WindowEvent e) {}
    public void windowDeactivated(WindowEvent e) {}

    public void paint(Graphics g) {
        theCanvas.paint(g);
	theToolbar.paint(g);
    }

}

