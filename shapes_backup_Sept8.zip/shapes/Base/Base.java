import java.applet.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JButton;
import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.AbstractAction;
import javax.swing.Action;
 
// The applet's class name must be identical to the filename.
public class Base extends JApplet
   implements MouseListener, MouseMotionListener {
 
   // Declare two variables of type "int" (integer).
   int width, height;
   int x, y;    // the coordinates of the upper-left corner of the box
   int mx, my;  // the most recently recorded mouse coordinates
   boolean isMouseDraggingBox = false;
 
   // This gets executed when the applet starts.
   public void init() {

      // Store the height and width of the applet for future reference.
      width = getSize().width;
      height = getSize().height;
      // Make the default background color black.
      setBackground( Color.white );
      x = width/2 - 20;
      y = height/2 - 20;
      addMouseListener( this );
      addMouseMotionListener( this );
    
       
   }
   public void paint( Graphics g ) {
      // Set the current drawing color to green.
      g.setColor( Color.black );
      // Draw ten lines using a loop.
      // We declare a temporary variable, i, of type "int".
      // Note that "++i" is simply shorthand for "i=i+1"
      for ( int i = 0; i < 10; ++i ) {
         // The "drawLine" routine requires 4 numbers:
         // the x and y coordinates of the starting point,
         // and the x and y coordinates of the ending point,
         // in that order.  Note that the cartesian plane,
         // in this case, is upside down (as it often is
         // in 2D graphics programming): the origin is at the
         // upper left corner, the x-axis increases to the right,
         // and the y-axis increases downward.
         g.drawLine( width, height, i * width / 10, 0 );
         // Draw point
         g.setColor( Color.gray );
         g.fillRect( x, y, 10, 10 );
      }
   }

   public void mouseEntered( MouseEvent e ) { }
   public void mouseExited( MouseEvent e ) { }
   public void mouseClicked( MouseEvent e ) { }
   public void mousePressed( MouseEvent e ) {
      mx = e.getX();
      my = e.getY();
      if ( x < mx && mx < x+40 && y < my && my < y+40 ) {
         isMouseDraggingBox = true;
      }
      e.consume();
   }
   public void mouseReleased( MouseEvent e ) {
      isMouseDraggingBox = false;
      e.consume();
   }
   public void mouseMoved( MouseEvent e ) { }
   public void mouseDragged( MouseEvent e ) {
      if ( isMouseDraggingBox ) {
         // get the latest mouse position
         int new_mx = e.getX();
         int new_my = e.getY();

         // displace the box by the distance the mouse moved since the last event
         // Note that "x += ...;" is just shorthand for "x = x + ...;"
         x += new_mx - mx;
         y += new_my - my;

         // update our data
         mx = new_mx;
         my = new_my;

         repaint();
         e.consume();
      }
   }
}   
