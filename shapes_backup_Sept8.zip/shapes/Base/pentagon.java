import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class pentagon extends JPanel implements ActionListener {
	
	private int n,r;
	private double angle;
	private int[] x,y;
	private double dv = 5*2*Math.PI/360;
	private double turn = 0.0;
	private Timer tim = new Timer(100, this);
	
public pentagon(int pieces, int radie) {
		n=pieces; r=radie;
		x = new int[n];
		y = new int[n];
		angle= 2*Math.PI/n;
	}
	
public void start() {
		tim.start();
	}
	public void stop() {
		tim.stop();
	}

public void actionPerformed(ActionEvent E) {
		turn= turn+dv;
		if(turn>2*Math.PI)
			turn-= 2*Math.PI;
		repaint();
	}
	
public void paintComponent(Graphics G) {
		super.paintComponents(G);
		int x0 = getSize().width/2;
		int y0 = getSize().height/2;
		
		for(int i=0; i<n; i++) {
			double v = i*angle- turn;
		x[i] = x0 + (int)Math.round(r*Math.cos(v));
		y[i] = y0 + (int)Math.round(r*Math.sin(v));
		}
		G.fillPolygon(x, y, n);
	}
}
