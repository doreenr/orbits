/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package universal;
import java.awt.event.*;

/**
 *
 * @author Doreen
 */
public class UController {
    
 private UModel model;
 private UView view; 
 private int iterations, expa, expb;
 
 public UController (UView v, UModel m)
 {
  model = m;
  view = v;
  view.setOutput(model.getoutmat(), model.getoutitPA(), model.getoutitPM());
  iterations = model.getit();
  view.addClickListener(new InitialListener()); 
  view.addIterationListener100p(new IterationListenerPlus100());
  view.addIterationListener100m(new IterationListenerMinus100());  
  view.addIterationListener1000p(new IterationListenerPlus1000());
  view.addIterationListener1000m(new IterationListenerMinus1000());
  view.addIterationListener(new IterationListener());
  view.addProListener(new ProjectionListener());
  view.addExpListenerA(new ExpListener());
  view.addExpListenerB(new ExpListener());
  view.addRadioListener(new RadioA());
 }
 
  class RadioA implements ActionListener {
      public void actionPerformed (ActionEvent evt) {
            String choice = view.getRadiosenderA();
            System.out.println("Radio A " + choice);
//            String newexpb = view.getexpb();
//            expa = Integer.valueOf(newexpa);            
//            expb = Integer.valueOf(newexpb);
//            model.setExponents(expa, expb);
//            model.reset();
//            // model.updateOrbit(iterations);
//            view.setOutput(model.getoutmat(), model.getoutitPA(), model.getoutitPM());
//            view.reset();
      }
  }
  
  class ExpListener implements ActionListener {
      public void actionPerformed (ActionEvent evt) {
            String newexpa = view.getexpa();
            String newexpb = view.getexpb();
            expa = Integer.valueOf(newexpa);            
            expb = Integer.valueOf(newexpb);
            model.setExponents(expa, expb);
            model.reset();
            // model.updateOrbit(iterations);
            view.setOutput(model.getoutmat(), model.getoutitPA(), model.getoutitPM());
            view.reset();
      }
  }  
   
  
  class InitialListener implements ActionListener {
      public void actionPerformed (ActionEvent evt) {
            model.reset();
            view.setOutput(model.getoutmat(), model.getoutitPA(), model.getoutitPM());
            view.reset();
            String newit = view.getIteration();
            iterations = Integer.valueOf(newit);
      }
  }
  class IterationListenerPlus100 implements ActionListener {
      public void actionPerformed (ActionEvent evt) {
            // System.out.println("getit " + iterations);
            iterations += 100;
            model.setit(iterations);
            model.updateOrbit(iterations);
            view.setOutput(model.getoutmat(), model.getoutitPA(), model.getoutitPM());
            view.reset();
      }
  }  
  class IterationListenerMinus100 implements ActionListener {
      public void actionPerformed (ActionEvent evt) {
            // System.out.println("getit " + iterations);
            if (iterations >= 100) {iterations -= 100;}
            model.setit(iterations);
            model.updateOrbit(iterations);
            view.setOutput(model.getoutmat(), model.getoutitPA(), model.getoutitPM());
            view.reset();
      }
  }
  
  class IterationListenerPlus1000 implements ActionListener {
      public void actionPerformed (ActionEvent evt) {
            // System.out.println("getit " + iterations);
            iterations += 1000;
            model.setit(iterations);
            model.updateOrbit(iterations);
            view.setOutput(model.getoutmat(), model.getoutitPA(), model.getoutitPM());
            view.reset();
      }
  }  
  class IterationListenerMinus1000 implements ActionListener {
      public void actionPerformed (ActionEvent evt) {
            // System.out.println("getit " + iterations);
            if (iterations >= 1000) {iterations -= 1000;}
            model.setit(iterations);
            model.updateOrbit(iterations);
            view.setOutput(model.getoutmat(), model.getoutitPA(), model.getoutitPM());
            view.reset();
      }
  }  
  
  class IterationListener implements ActionListener {
      public void actionPerformed (ActionEvent evt) {
            // System.out.println("getit " + iterations);
            String newit = view.getIteration();
            iterations = Integer.valueOf(newit);
            model.setit(iterations);
            model.updateOrbit(iterations);
            view.setOutput(model.getoutmat(), model.getoutitPA(), model.getoutitPM());
            view.reset();
      }
  }  
  class ProjectionListener implements ActionListener {
      public void actionPerformed (ActionEvent evt) {
            String[] a;
            a = view.getProjections();
            model.setProjections(a);
            System.out.println("getpro " + a[0]);
//            if (iterations >= 100) {iterations -= 100;}
//            model.setit(iterations);
//            model.updateOrbit(iterations);
//            view.setOutput(model.getoutmat(), model.getoutit());
            view.reset();
      }
  }
 
/*
  public void ActionListenerMoth(ActionListener ae) {
      view.jButton1.addActionListener(ae);
  }*/
 
}  




/*  
  class InitialListener implements ActionListener {
      view.jButton1.addActionListener((new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
       });
  } 
private void jButton1ActionPerformed(ActionEvent evt) {                                         
    System.out.println("You clicked the Initialize button");
    canvasPI.repaint();  
    // Coord.getInstance(1);
    canvasRP.repaint();
    subcanvas.repaint();
    } */

//  public void InitialListener(ActionListener ae){
//      view.jButton2.addActionListener((new java.awt.event.ActionListener() {
//            public void actionPerformed(java.awt.event.ActionEvent evt) {
//                jChHHWHWHHWHWHWHH!Box4ActionPerformed(evt);
//            }
//       });
//  }  
//  
//  public void InitialListener(ActionListener ae){
//      view.jCheckBox1.addActionListener((new java.awt.event.ActionListener() {
//            public void actionPerformed(java.awt.event.ActionEvent evt) {
//                jCheckBox4ActionPerformed(evt);
//            }
//       });
//  }
//  
//  
//  public void InitialListener(ActionListener ae){
//      view.jCheckBox2.addActionListener((new java.awt.event.ActionListener() {
//            public void actionPerformed(java.awt.event.ActionEvent evt) {
//                jCheckBox4ActionPerformed(evt);
//            }
//       });
//  }
//  public void InitialListener(ActionListener ae){
//      view.jCheckBox3.addActionListener((new java.awt.event.ActionListener() {
//            public void actionPerformed(java.awt.event.ActionEvent evt) {
//                jCheckBox4ActionPerformed(evt);
//            }
//       });
//  }
//    public void InitialListener(ActionListener ae){
//      view.jCheckBox4.addActionListener((new java.awt.event.ActionListener() {
//            public void actionPerformed(java.awt.event.ActionEvent evt) {
//                jCheckBox4ActionPerformed(evt);
//            }
//       });
//  }
 


//private void jButton2ActionPerformed(ActionEvent evt) {                                         
//        // TODO add your handling code here:
//    }                                        
//
//private void jCheckBox1ActionPerformed(ActionEvent evt) {                                           
//        // TODO add your handling code here:
//    }                                          
//
//private void jCheckBox2ActionPerformed(ActionEvent evt) {                                           
//        // TODO add your handling code here:
//    }                                          
//
//private void jCheckBox3ActionPerformed(ActionEvent evt) {                                           
//        // TODO add your handling code here:
//    }                                          
//
//private void jCheckBox4ActionPerformed(ActionEvent evt) {                                           
//        // TODO add your handling code here:
//    }
// }
 
