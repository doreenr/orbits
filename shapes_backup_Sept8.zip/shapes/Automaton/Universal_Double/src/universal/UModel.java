/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package universal;
import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.math.BigDecimal;

/**
 *
 * @author Doreen
 */
public class UModel {
    
    // constants
    
    // current state variables
    public int vertices = 88;
    public int n = 3;
    public int iterations = 28;
    private Complex[] d, pox;
    private Complex exponents = new Complex(1,1);
    private Gon polygon, polybig; //= new Gon(vertices, iteration);
    private MMatrix M, paorbitx, paorbity, pmorbitx, pmorbity;
    private String outitPA, outitPM, outmat, polylistPA, polylistPM;
    private Orbit orbit, bigorbit;
    private Zeichnen zeichne = new Zeichnen();
    private String[] projections;
    private BigDecimal[] bigx, bigy, bigxn, bigyn;
    private BigDecimal[][] bigpaorbx, bigpaorby, bigpmorbx, bigpmorby;
    
    
    // projections = setProjections(null);
    
    UModel() {
        reset();
    }
    
    public void reset() {
            System.out.println("Anpassen von in/de-creasing proj length!");

        /// System.out.println("exponents reset " + exponents.x + exponents.y);
        polygon = new Gon(n, vertices, exponents);
        M = polygon.getM();
        d = polygon.getd();
        pox = polygon.getPx();
        orbit = new Orbit(pox, iterations);
        paorbitx = orbit.PentAutOrbitX();
        paorbity = orbit.PentAutOrbitY();        
        pmorbitx = orbit.PentMapOrbitX();
        pmorbity = orbit.PentMapOrbitY();
        polylistPA = finiteany(paorbitx, paorbity);
        polylistPM = finiteany(pmorbitx, pmorbity);
        outitPA = setOutputItPA(polylistPA);
        outitPM = setOutputItPM(polylistPM);        
        outmat = setOutputMat(M, pox);
        
        // BIG WAY
        polybig = new Gon(n, vertices, exponents);
        bigx = polybig.getbigx();
        bigy = polybig.getbigy();
        bigxn = polybig.getbigxn();
        bigyn = polybig.getbigyn();
        bigorbit = new Orbit(iterations);
        bigpaorbx = bigorbit.BigPentAutOrbitX(bigxn, bigyn);
        bigpaorby = bigorbit.BigPentAutOrbitY(bigxn, bigyn);        
        bigpmorbx = bigorbit.BigPentMapOrbitX(bigxn, bigyn);
        bigpmorby = bigorbit.BigPentMapOrbitY(bigxn, bigyn);
        
// bigx not used
        
    } 
    
    public void updateOrbit(int newit) {
        orbit = new Orbit(pox, newit);
        paorbitx = orbit.PentAutOrbitX();
        paorbity = orbit.PentAutOrbitY();        
        pmorbitx = orbit.PentMapOrbitX();
        pmorbity = orbit.PentMapOrbitY();
        polylistPA = finiteany(paorbitx, paorbity);
        polylistPM = finiteany(pmorbitx, pmorbity);
        outitPA = setOutputItPA(polylistPA);
        outitPM = setOutputItPM(polylistPM);
        outmat = setOutputMat(M, pox);
    }
    
    public int getit() {
        return iterations;
    }     
    
    public void setProjections(String[] proj) {
        projections = proj;
    }    
    
    public void setExponents(int expa, int expb) {
        exponents = new Complex(expa, expb);
    }    
    
    public Complex getExponents() {
        return exponents;
    }   
    
    public String[] getProjections() {
        return projections;
    } 
    
    public int setit(int newit) {
        iterations = newit;
        return iterations;
    }
    
    void displayAll(Graphics2D g, int choice, double ps, int iter) {
        iterations = iter;
        if (choice == 1) {
            float f = 0.1F;
            for (int i = 0; i < (bigx.length-1); ++i) {
                // if (i % n == 0 && f < 0.9F ) { f += 0.1F; }
                g.setColor(Color.black);
                // System.out.println("i " + i + ", bx " + bigx[i] +", " + bigy[i]);
                zeichne.Dot(g, bigx[i], bigy[i], 2, f);  }
            f = 0.6F;
            for (int i = 0; i < bigxn.length; ++i) {
                g.setColor(Color.RED);
                zeichne.Dot(g, bigxn[i], bigyn[i], 2, f); }
        }
        else if (choice == 2) {
            // zeichne.ZeichneOrbit(g, paorbitx, paorbity, projections, ps);
            zeichne.ZeichneBigOrbit(g, bigpaorbx, bigpaorby, projections, ps);
        }
        else if (choice == 3) {
            // zeichne.ZeichneOrbit(g, paorbitx, paorbity, projections, ps);
            zeichne.ZeichneBigOrbit(g, bigpmorbx, bigpmorby, projections, ps);
        }
    }

    
    public String finiteany(MMatrix Mx, MMatrix My) {
        // System.out.println(" Mx.rows = " + Mx.rows + ", Mx.columns = " + Mx.columns);
        StringBuilder build = new StringBuilder();
        List<String> list = new ArrayList<String>();
        // create full row as string, save in list of strings 
        for (int l = 0; l < paorbitx.rows; ++l) {
            if (Mx.columns == 1) {
            double temp1 = Mx.element[l][0]; 
            String a1 = String.valueOf(temp1); 
            build.append(a1);
            list.add(build.toString());
            build.setLength(0);
            }
            if (Mx.columns == 2) {
            double temp1 = Mx.element[l][0];
            double temp2 = Mx.element[l][1];
            String a1 = String.valueOf(temp1);
            String a2 = String.valueOf(temp2);
            build.append(a1);
            build.append(a2);
            // System.out.println(" row: " + l + ", string: " + build.toString());
            list.add(build.toString());
            build.setLength(0); }
            if (Mx.columns == 3) {
            double temp1 = Mx.element[l][0];
            double temp2 = Mx.element[l][1];
            double temp3 = Mx.element[l][2];
            String a1 = String.valueOf(temp1);
            String a2 = String.valueOf(temp2);
            String a3 = String.valueOf(temp3);
            build.append(a1);
            build.append(a2);
            build.append(a3);
            // System.out.println(" row: " + l + ", string: " + build.toString());
            list.add(build.toString());
            build.setLength(0); } 
            
            if (Mx.columns == 4) {
            double temp1 = Mx.element[l][0]; String a1 = String.valueOf(temp1); build.append(a1);
            double temp2 = Mx.element[l][1]; String a2 = String.valueOf(temp2); build.append(a2);
            double temp3 = Mx.element[l][2]; String a3 = String.valueOf(temp3); build.append(a3);
            double temp4 = Mx.element[l][3]; String a4 = String.valueOf(temp4); build.append(a4);
            list.add(build.toString());
            build.setLength(0); }           
            
            if (Mx.columns == 5) {
            double temp1 = Mx.element[l][0]; String a1 = String.valueOf(temp1); build.append(a1);
            double temp2 = Mx.element[l][1]; String a2 = String.valueOf(temp2); build.append(a2);
            double temp3 = Mx.element[l][2]; String a3 = String.valueOf(temp3); build.append(a3);
            double temp4 = Mx.element[l][3]; String a4 = String.valueOf(temp4); build.append(a4);
            double temp5 = Mx.element[l][4]; String a5 = String.valueOf(temp5); build.append(a5);
            list.add(build.toString());
            build.setLength(0); }
            
            if (Mx.columns == 6) {
            double temp1 = Mx.element[l][0]; String a1 = String.valueOf(temp1); build.append(a1);
            double temp2 = Mx.element[l][1]; String a2 = String.valueOf(temp2); build.append(a2);
            double temp3 = Mx.element[l][2]; String a3 = String.valueOf(temp3); build.append(a3);
            double temp4 = Mx.element[l][3]; String a4 = String.valueOf(temp4); build.append(a4);
            double temp5 = Mx.element[l][4]; String a5 = String.valueOf(temp5); build.append(a5);
            double temp6 = Mx.element[l][5]; String a6 = String.valueOf(temp6); build.append(a6);
            list.add(build.toString());
            build.setLength(0); }
            
            if (Mx.columns == 7) {
            double temp1 = Mx.element[l][0]; String a1 = String.valueOf(temp1); build.append(a1);
            double temp2 = Mx.element[l][1]; String a2 = String.valueOf(temp2); build.append(a2);
            double temp3 = Mx.element[l][2]; String a3 = String.valueOf(temp3); build.append(a3);
            double temp4 = Mx.element[l][3]; String a4 = String.valueOf(temp4); build.append(a4);
            double temp5 = Mx.element[l][4]; String a5 = String.valueOf(temp5); build.append(a5);
            double temp6 = Mx.element[l][5]; String a6 = String.valueOf(temp6); build.append(a6);
            double temp7 = Mx.element[l][6]; String a7 = String.valueOf(temp7); build.append(a7);
            list.add(build.toString());
            build.setLength(0); }            
            
            if (Mx.columns == 8) {
            double temp1 = Mx.element[l][0]; String a1 = String.valueOf(temp1); build.append(a1);
            double temp2 = Mx.element[l][1]; String a2 = String.valueOf(temp2); build.append(a2);
            double temp3 = Mx.element[l][2]; String a3 = String.valueOf(temp3); build.append(a3);
            double temp4 = Mx.element[l][3]; String a4 = String.valueOf(temp4); build.append(a4);
            double temp5 = Mx.element[l][4]; String a5 = String.valueOf(temp5); build.append(a5);
            double temp6 = Mx.element[l][5]; String a6 = String.valueOf(temp6); build.append(a6);
            double temp7 = Mx.element[l][6]; String a7 = String.valueOf(temp7); build.append(a7);
            double temp8 = Mx.element[l][7]; String a8 = String.valueOf(temp8); build.append(a8);
            list.add(build.toString());
            build.setLength(0); }
        }
        // System.out.println("\nCount all with frequency");
	Set<String> uniqueSet = new HashSet<String>(list);
        StringBuilder polylist = new StringBuilder();
	for (String temp : uniqueSet) {
                int tempo = Collections.frequency(list, temp);
                // System.out.println(temp + ": " + tempo);
                polylist.append(tempo);
                polylist.append(", ");
	}
        return polylist.toString();
    }
    
    public void setn(int newn) {
        n = newn;
    }
    public int getn() {
        return n;
    }    
    public void setv(int newv) {
        vertices = newv;
    }
    public int getv() {
        return vertices;
    }    
    
    public String getoutitPA() {
        return outitPA;
    }     
    public String getoutitPM() {
        return outitPM;
    }     
    
    public String getoutmat() {
        return outmat;
    }    
    
    public String setOutputMat(MMatrix M, Complex[] pox) {
        String label = "Matrix. ";
        String labelv = "Initial vertices. ";
        String labeli = "Iterations. ";
        String M1 = String.format("|  %.2f", M.element[0][0]);        
        String M2 = String.format("   %.0f  |", M.element[0][1]);        
        String M3 = String.format("|  %.0f", M.element[1][0]);        
        String M4 = String.format("   %.2f  |", M.element[1][1]);
        String iPA = String.valueOf(iterations);
        String px1 = String.format("V1  %.2f, ", pox[0].x);        
        String py1 = String.format(" %.2f", pox[0].y);
        String last = "Choice of 2D-         projection from        matrices MX & MY,  for (s,t) where         s,t = {0,1, ... n-1}";
        String last1 = "P1 [red]                 P2 [blue]                 P3 [orange]             P4 [magenta]          P5 [turquoise]         P6 [green]               P7 [gray]";
        // "ersteZeile"+'\r'+'\n'+"zweiteZeile";
        
        String s3 = label +'\n'+ M1 + M2 +'\n'+ M3+ M4 +'\n'+'\n'+ labelv  + px1 + py1 +'\n'+ labeli + iPA + '\n'+'\n'+ last  + '\n'+'\n'+ last1;
        if (pox.length > 1) {
        String px2 = String.format("V2  %.2f, ", pox[1].x);        
        String py2 = String.format(" %.2f", pox[1].y); 
        s3 = label +'\n'+ M1 + M2 +'\n'+ M3 + M4 +'\n'+ '\n'+ labelv  + px1 + py1 + '\n'+ px2 + py2 +'\n'+'\n'+ labeli + iPA + '\n'+'\n'+ last + '\n'+'\n'+ last1;
        } 
        if (pox.length > 2) {
        String px2 = String.format("V2  %.2f, ", pox[1].x);        
        String py2 = String.format(" %.2f", pox[1].y);              
        String px3 = String.format("V3  %.2f, ", pox[2].x);        
        String py3 = String.format(" %.2f", pox[2].y);      
        s3 = label + '\n'+ M1 + M2 +'\n'+  M3 + M4 +'\n'+'\n'+  labelv +'\n'+  px1 + py1 +'\n'+  px2 + py2+'\n'+ px3 + py3 +'\n'+'\n'+ labeli + iPA + '\n'+'\n'+ last + '\n'+'\n'+ last1;
        }  
        if (pox.length > 3) {
        String px2 = String.format("V2  %.2f, ", pox[1].x);        
        String py2 = String.format(" %.2f", pox[1].y);              
        String px3 = String.format("V3  %.2f, ", pox[2].x);        
        String py3 = String.format(" %.2f", pox[2].y);         
        String px4 = String.format("V4  %.2f, ", pox[3].x);        
        String py4 = String.format(" %.2f", pox[3].y);      
        s3 = label +'\n'+ M1 + M2 +'\n'+ M3 + M4 +'\n'+'\n'+  labelv  +'\n'+ px1 + py1 +'\n'+  px2 + py2+'\n'+ px3 + py3 +'\n'+ px4 + py4 +'\n'+ '\n'+labeli + iPA + '\n'+'\n'+ last+ '\n'+'\n'+ last1;
        } 
        if (pox.length > 4) {
        String px2 = String.format("V2  %.2f, ", pox[1].x);        
        String py2 = String.format(" %.2f", pox[1].y);              
        String px3 = String.format("V3  %.2f, ", pox[2].x);        
        String py3 = String.format(" %.2f", pox[2].y);         
        String px4 = String.format("V4  %.2f, ", pox[3].x);        
        String py4 = String.format(" %.2f", pox[3].y);  
        String px5 = String.format("V5  %.2f, ", pox[4].x);        
        String py5 = String.format(" %.2f", pox[4].y);      
        s3 = label +'\n'+ M1 + M2 +'\n'+ M3 + M4 +'\n'+'\n'+ labelv  + px1 + py1 +'\n'+  px2 + py2+'\n'+ px3 + py3 +'\n'+ px4 + py4+'\n'+ px5 + py5 +'\n'+'\n'+ labeli + iPA + '\n'+'\n'+ last + '\n'+'\n'+ last1;
        } 
        if (pox.length > 5) {  
        s3 = label +'\n'+ M1 + M2 +'\n'+ M3 + M4 +'\n'+'\n'+ labeli + iPA + '\n'+'\n'+ last + '\n'+'\n'+ last1;

        }
        return s3;
    }
        
    public String setOutputItPA(String poly1) {
        String labellist = "PA. Counting resulting polygons.  ";
        String s3 = labellist + poly1;
        return s3;
    }     
    
    public String setOutputItPM(String poly2) {
        String labellist = "PM. Counting resulting polygons.  ";
        String s3 = labellist + poly2;
        return s3;
    } 
    

    

    

    
    

}    

    
    
    
    

