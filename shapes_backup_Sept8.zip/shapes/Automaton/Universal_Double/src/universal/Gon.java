/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package universal;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 *
 * @author Doreen
 */
public class Gon {
    private int n, vertices;
    private static Complex c, exponents; // = randAB();
    private static MMatrix M;     
    private Complex[] d, pox; // = getPoints(M, 2);
    private BigDecimal[] big, bign, bigx, bigy, bigxn, bigyn;
    private BigDecimal A, B;
    
    public Gon (int ns, int vert, Complex expo) {
        vertices = vert;// = Math.abs(ns);
        exponents = expo;
        n = ns;
        c = randAB(exponents);
        M = getMatrix(c);
        d = getPoints(M);
        pox = getnPoints(d);        
       
        // BIG WAY 
        A = bigrand("a");
        B = bigrand("b");
//        System.out.println("gon a " + A);
//        System.out.println("gon b " + B);
        bigx = getBigPoints(A);
        bigy = getBigPoints(B);
//        for (int i = 0; i<bigx.length; ++i) {
//            System.out.println("bigx " + bigx[i]);
//        }
        bigxn = getnBigPoints(bigx);
        bigyn = getnBigPoints(bigy);
    }
    
    public BigDecimal[] getbigx() {
        return bigx;
    }    
    public BigDecimal[] getbigy() {
        return bigy;
    }
    public BigDecimal[] getbigxn() {
        return bigxn;
    }    
    public BigDecimal[] getbigyn() {
        return bigyn;
    }    

    public MMatrix getM() {
        return M;
    }   
    
    public Complex[] getd() {
        return d;
    }
    
    public Complex[] getPx() {
        return pox;
    }    
    
    
    public Complex[] getnPoints(Complex[] d) {
        pox = new Complex[n];
        for (int i = 0; i < n; ++i) {
            // System.out.println(n);
            pox[i] = new Complex(d[i+n].x, d[i+n].y); 
        }
        return pox;
    }
    
    public BigDecimal[] getnBigPoints(BigDecimal[] C) {
        bign = new BigDecimal[n];
        for (int i = 0; i < n; ++i) {
            bign[i] = C[i+n];
            // System.out.println("C.length: " + C.length);
            // System.out.println("big i + n: " + C[i+n]);
        }
        return bign;
    }
    
    
    public BigDecimal[] getBigPoints(BigDecimal C) {
        big = new BigDecimal[vertices];
        if (n == 1) { for (int i = 0; i < vertices; ++i) {
//            System.out.println("C:  " + C);
            BigDecimal iB = BigDecimal.valueOf(i);
//            System.out.println("iB:  " + iB);
            BigDecimal VB = C.multiply(iB);
//            System.out.println("VB:  " + VB);
            big[i] = VB;
//            System.out.println("***************");
            } 
        }
        else if (n == 2) { for (int i = 0; i < (vertices-1); ++i) {
//            System.out.println("C:  " + C);
            BigDecimal iB = BigDecimal.valueOf(i);
//            System.out.println("iB:  " + iB);
            BigDecimal VB = C.multiply(iB);
//            System.out.println("VB:  " + VB);
            big[i] = VB;
            BigDecimal VB2 = C.multiply(VB);
//            System.out.println("VB2:  " + VB2);  
            big[i+1] = VB2;
//            System.out.println("***************");            
            i += 1; } }
        else if (n == 3) { for (int i = 0; i < (vertices-1); ++i) {
//            System.out.println("C:  " + C);
            BigDecimal iB = BigDecimal.valueOf(i);
//            System.out.println("iB:  " + iB);
            BigDecimal VB = C.multiply(iB);
//            System.out.println("VB:  " + VB);
            big[i] = VB;
            BigDecimal VB2 = C.multiply(VB);
//            System.out.println("VB2:  " + VB2);  
            big[i+1] = VB2;
            BigDecimal VB3 = C.multiply(VB2);
//            System.out.println("VB3:  " + VB3);  
            big[i+2] = VB3;            
//            System.out.println("***************");            
            i += 2; } }
        else if (n == 4) { for (int i = 0; i < (vertices-1); ++i) {
//            System.out.println("C:  " + C);
            BigDecimal iB = BigDecimal.valueOf(i);
//            System.out.println("iB:  " + iB);
            BigDecimal VB = C.multiply(iB);
//            System.out.println("VB:  " + VB);
            big[i] = VB;
            BigDecimal VB2 = C.multiply(VB);
//            System.out.println("VB2:  " + VB2);  
            big[i+1] = VB2;
            BigDecimal VB3 = C.multiply(VB2);
//            System.out.println("VB3:  " + VB3);  
            big[i+2] = VB3;            
            BigDecimal VB4 = C.multiply(VB3);
//            System.out.println("VB4:  " + VB4);  
            big[i+3] = VB4;  
//            System.out.println("***************");            
            i += 3; } }  
        else if (n == 5) { for (int i = 0; i < (vertices-1); ++i) {
//            System.out.println("C:  " + C);
            BigDecimal iB = BigDecimal.valueOf(i);
//            System.out.println("iB:  " + iB);
            BigDecimal VB = C.multiply(iB);
//            System.out.println("VB:  " + VB);
            big[i] = VB;
            BigDecimal VB2 = C.multiply(VB);
//            System.out.println("VB2:  " + VB2);  
            big[i+1] = VB2;
            BigDecimal VB3 = C.multiply(VB2);
//            System.out.println("VB3:  " + VB3);  
            big[i+2] = VB3;            
            BigDecimal VB4 = C.multiply(VB3);
//            System.out.println("VB4:  " + VB4);  
            big[i+3] = VB4;  
            BigDecimal VB5 = C.multiply(VB4);
//            System.out.println("VB5:  " + VB5);  
            big[i+4] = VB5;  
//            System.out.println("***************");            
            i += 4; } } 
        else if (n == 6) { for (int i = 0; i < (vertices-1); ++i) {
//            System.out.println("C:  " + C);
            BigDecimal iB = BigDecimal.valueOf(i);
//            System.out.println("iB:  " + iB);
            BigDecimal VB = C.multiply(iB);
//            System.out.println("VB:  " + VB);
            big[i] = VB;
            BigDecimal VB2 = C.multiply(VB);
//            System.out.println("VB2:  " + VB2);  
            big[i+1] = VB2;
            BigDecimal VB3 = C.multiply(VB2);
//            System.out.println("VB3:  " + VB3);  
            big[i+2] = VB3;            
            BigDecimal VB4 = C.multiply(VB3);
//            System.out.println("VB4:  " + VB4);  
            big[i+3] = VB4;  
            BigDecimal VB5 = C.multiply(VB4);
//            System.out.println("VB5:  " + VB5);  
            big[i+4] = VB5;  
            BigDecimal VB6 = C.multiply(VB5);
//            System.out.println("VB6:  " + VB6);  
            big[i+5] = VB6; 
//            System.out.println("***************");            
            i += 5; } }  
        else if (n == 7) { for (int i = 0; i < (vertices-1); ++i) {
//            System.out.println("C:  " + C);
            BigDecimal iB = BigDecimal.valueOf(i);
//            System.out.println("iB:  " + iB);
            BigDecimal VB = C.multiply(iB);
//            System.out.println("VB:  " + VB);
            big[i] = VB;
            BigDecimal VB2 = C.multiply(VB);
//            System.out.println("VB2:  " + VB2);  
            big[i+1] = VB2;
            BigDecimal VB3 = C.multiply(VB2);
//            System.out.println("VB3:  " + VB3);  
            big[i+2] = VB3;            
            BigDecimal VB4 = C.multiply(VB3);
//            System.out.println("VB4:  " + VB4);  
            big[i+3] = VB4;  
            BigDecimal VB5 = C.multiply(VB4);
//            System.out.println("VB5:  " + VB5);  
            big[i+4] = VB5;  
            BigDecimal VB6 = C.multiply(VB5);
//            System.out.println("VB6:  " + VB6);  
            big[i+5] = VB6; 
            BigDecimal VB7 = C.multiply(VB6);
//            System.out.println("VB7:  " + VB7);  
            big[i+6] = VB7;
//            System.out.println("***************");            
            i += 6; } } 
        else if (n == 8) { for (int i = 0; i < (vertices-1); ++i) {
//            System.out.println("C:  " + C);
            BigDecimal iB = BigDecimal.valueOf(i);
//            System.out.println("iB:  " + iB);
            BigDecimal VB = C.multiply(iB);
//            System.out.println("VB:  " + VB);
            big[i] = VB;
            BigDecimal VB2 = C.multiply(VB);
//            System.out.println("VB2:  " + VB2);  
            big[i+1] = VB2;
            BigDecimal VB3 = C.multiply(VB2);
//            System.out.println("VB3:  " + VB3);  
            big[i+2] = VB3;            
            BigDecimal VB4 = C.multiply(VB3);
//            System.out.println("VB4:  " + VB4);  
            big[i+3] = VB4;  
            BigDecimal VB5 = C.multiply(VB4);
//            System.out.println("VB5:  " + VB5);  
            big[i+4] = VB5;  
            BigDecimal VB6 = C.multiply(VB5);
//            System.out.println("VB6:  " + VB6);  
            big[i+5] = VB6; 
            BigDecimal VB7 = C.multiply(VB6);
//            System.out.println("VB7:  " + VB7);  
            big[i+6] = VB7;
            BigDecimal VB8 = C.multiply(VB7);
//            System.out.println("VB8:  " + VB8);  
            big[i+7] = VB8;
//            System.out.println("***************");            
            i += 7; } }          
        return big; 
        }
        
    public Complex[] getPoints(MMatrix M) {
        d = new Complex[vertices];
        double a = M.element[0][0];
        double b = M.element[1][1];
        if (n == 1) { for (int i = 0; i < vertices; ++i) {
            // System.out.println("n = 1, i:  " + i);
            double vx = i*a;
            double vy = i*b;
            d[i] = new Complex (vx, vy); } }
        else if (n == 2) { for (int i = 0; i < (vertices-1); ++i) {
            // System.out.println("n = 2, i:  " + i);
            double vx = a*i;
            double vy = b*i;
            d[i] = new Complex (vx, vy);
            //System.out.println("i:  " + i + "  d.i.x:  " + d[i].x);
            double vx2 = vx*a;
            double vy2 = vy*b;
            d[i+1] = new Complex (vx2, vy2);
            //System.out.println("i:  " + i + "  d.1+i.x:  " + d[i+1].x);
            i += 1; } }
        else if (n == 3) { for (int i = 0; i < (vertices-(n-1)); ++i) {
            double vx1 = a*i;
            double vy1 = b*i;
            d[i] = new Complex (vx1, vy1);
            double vx2 = vx1*a;
            double vy2 = vy1*b;
            d[i+1] = new Complex (vx2, vy2);
            double vx3 = vx2*a;
            double vy3 = vy2*b;
            d[i+2] = new Complex (vx3, vy3); 
            i += 2; } }        
        else if (n == 4) { for (int i = 0; i < (vertices-(n-1)); ++i) {
            double vx1 = a*i;
            double vy1 = b*i;
            d[i] = new Complex (vx1, vy1);
            double vx2 = vx1*a;
            double vy2 = vy1*b;
            d[i+1] = new Complex (vx2, vy2);
            double vx3 = vx2*a;
            double vy3 = vy2*b;
            d[i+2] = new Complex (vx3, vy3);             
            double vx4 = vx3*a;
            double vy4 = vy3*b;
            d[i+3] = new Complex (vx4, vy4); 
            i += 3; } }        
        else if (n == 5) { for (int i = 0; i < (vertices-(n-1)); ++i) {
            double vx1 = a*i;
            double vy1 = b*i;
            d[i] = new Complex (vx1, vy1);
            double vx2 = vx1*a;
            double vy2 = vy1*b;
            d[i+1] = new Complex (vx2, vy2);
            double vx3 = vx2*a;
            double vy3 = vy2*b;
            d[i+2] = new Complex (vx3, vy3);             
            double vx4 = vx3*a;
            double vy4 = vy3*b;
            d[i+3] = new Complex (vx4, vy4);             
            double vx5 = vx4*a;
            double vy5 = vy4*b;
            d[i+4] = new Complex (vx5, vy5); 
            i += 4; } }        
        else if (n == 6) { for (int i = 0; i < (vertices-(n-1)); ++i) {
            double vx1 = a*i;
            double vy1 = b*i;
            d[i] = new Complex (vx1, vy1);
            double vx2 = vx1*a;
            double vy2 = vy1*b;
            d[i+1] = new Complex (vx2, vy2);
            double vx3 = vx2*a;
            double vy3 = vy2*b;
            d[i+2] = new Complex (vx3, vy3);             
            double vx4 = vx3*a;
            double vy4 = vy3*b;
            d[i+3] = new Complex (vx4, vy4);             
            double vx5 = vx4*a;
            double vy5 = vy4*b;
            d[i+4] = new Complex (vx5, vy5);             
            double vx6 = vx5*a;
            double vy6 = vy5*b;
            d[i+5] = new Complex (vx6, vy6); 
            i += 5; } }        
        else if (n == 7) { for (int i = 0; i < (vertices-(n-1)); ++i) {
            double vx1 = a*i;
            double vy1 = b*i;
            d[i] = new Complex (vx1, vy1);
            double vx2 = vx1*a;
            double vy2 = vy1*b;
            d[i+1] = new Complex (vx2, vy2);
            double vx3 = vx2*a;
            double vy3 = vy2*b;
            d[i+2] = new Complex (vx3, vy3);             
            double vx4 = vx3*a;
            double vy4 = vy3*b;
            d[i+3] = new Complex (vx4, vy4);             
            double vx5 = vx4*a;
            double vy5 = vy4*b;
            d[i+4] = new Complex (vx5, vy5);             
            double vx6 = vx5*a;
            double vy6 = vy5*b;
            d[i+5] = new Complex (vx6, vy6);             
            double vx7 = vx6*a;
            double vy7 = vy6*b;
            d[i+6] = new Complex (vx7, vy7); 
            i += 6; } }        
        else if (n == 8) { for (int i = 0; i < (vertices-(n-1)); ++i) {
            double vx1 = a*i;
            double vy1 = b*i;
            d[i] = new Complex (vx1, vy1);
            double vx2 = vx1*a;
            double vy2 = vy1*b;
            d[i+1] = new Complex (vx2, vy2);
            double vx3 = vx2*a;
            double vy3 = vy2*b;
            d[i+2] = new Complex (vx3, vy3);             
            double vx4 = vx3*a;
            double vy4 = vy3*b;
            d[i+3] = new Complex (vx4, vy4);             
            double vx5 = vx4*a;
            double vy5 = vy4*b;
            d[i+4] = new Complex (vx5, vy5);             
            double vx6 = vx5*a;
            double vy6 = vy5*b;
            d[i+5] = new Complex (vx6, vy6);             
            double vx7 = vx6*a;
            double vy7 = vy6*b;
            d[i+6] = new Complex (vx7, vy7);             
            double vx8 = vx7*a;
            double vy8 = vy7*b;
            d[i+7] = new Complex (vx8, vy8); 
            i += 7; } }
        return d; 
        }
    
//    public Complex[] getItPoints(MMatrix M, Complex startpoint) {        
//        d = new Complex[vertices];
//        double a = M.element[0][0];
//        double b = M.element[1][1];
//        double Ma0 = M.element[0][1];
//        double M0b = M.element[1][0];
//        double[][] Mab = new double[2][2];
//        Matrix inv = new Matrix(Mab);
//        inv.set(0,0, a);
//        inv.set(0,1, Ma0);
//        inv.set(1,0, M0b);
//        inv.set(1,1, b);
//        inv = inv.inverse();
//        double a2 = inv.get(0,0);
//        double b2 = inv.get(1,1);
//        // System.out.println("inv 00, inv 01: " + inv.get(0, 0) + ", " +inv.get(0, 1));
//        // System.out.println("inv 10, inv 11: " + inv.get(1, 0) + ", " +inv.get(1, 1));
//
//        if (n < 0) {
//            d[0] = new Complex(a2 * startpoint.x, b2 * startpoint.y);
//            double dxread = d[0].x;
//            double dyread = d[0].y;
//            for (int k = 1; k < vertices; ++k) {
//                d[k] = new Complex(a2 * dxread, b2 * dyread);
//                dxread = d[k].x;
//                dyread = d[k].y; 
//            // System.out.println("dk, dk.y: " + d[k].x + ", " + d[k].y);
//            }            
//        }
//        else if (n > 0) {
//            d[0] = new Complex(a * startpoint.x, b * startpoint.y);
//            double dxread = d[0].x;
//            double dyread = d[0].y;
//            for (int k = 1; k < vertices; ++k) {
//                d[k] = new Complex(a * dxread, b * dyread);
//                dxread = d[k].x;
//                dyread = d[k].y; 
//            // System.out.println("dk.x, dk.y: " + d[k].x + ", " + d[k].y);
//            }            
//        }
//        return d; }      

    
    private static MMatrix getMatrix(Complex c) {
        MMatrix New = new MMatrix(2,2);
        New.element[0][0] = c.x; // a = c.x
        New.element[0][1] = 0;
        New.element[1][0] = 0;
        New.element[1][1] = c.y; // b = c.y
        return New; 
    }
    
    private static Complex randAB(Complex exp) {
        double a = Math.random();
        double expa = exp.x;
        Complex c = new Complex();
        c.x = Math.pow(a,expa);
        double b = (Math.random()*0.00000000000000001)+1;
        double expb = exp.y;
        c.y = Math.pow(b,expb);
        return c; 
    } 
    
    private static BigDecimal bigrand(String choice) {
        BigDecimal A = new Big().getB();
        if (choice == "a") {
           return A; 
        }
        else if (choice == "b") {
            BigDecimal B = A.add(new BigDecimal("1"));
            return B;
        }
        else { return A; } 
    }
    
    
        

    
    // return value to controller
   
    
}
