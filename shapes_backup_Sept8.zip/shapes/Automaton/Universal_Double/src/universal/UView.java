/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package universal;

import java.awt.event.*;
import java.awt.*;
import javax.swing.JFrame;

/**
 *
 * @author Doreen
 */
class UView extends JFrame {
    // constants 
    
    private UModel model;
    private CanvasIP canvas1;
    private CanvasOrbPM canvas2;
    private CanvasOrbPA canvas3;    
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JRadioButton jRadioButton7;
    private javax.swing.JRadioButton jRadioButton8;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JRadioButton jRadioButton6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextArea jTextArea3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    // End of variables declaration                   


    
    private String[] proj;



    UView(UModel m) {
        model = m;
        // int n = model.n;
        proj = new String[8];
        String in0 = "(0,0)";
        String in1 = "(1,1)";
        String in2 = "(2,2)";
        String in3 = "(3,3)";
        String in4 = "(4,4)";
        String in5 = "(5,5)";
        String in6 = "(6,6)";
        String in7 = "(7,7)";
        String inno = "-";
        
        if (model.n == 1) {
            proj[0] = in0;
            proj[1] = inno;
            proj[2] = inno;
            proj[3] = inno;
            proj[4] = inno;
            proj[5] = inno;
            proj[6] = inno;
            proj[7] = inno;            
        }
        else if (model.n == 2) {
            proj[0] = in0;
            proj[1] = in1;
            proj[2] = inno;
            proj[3] = inno;
            proj[4] = inno;
            proj[5] = inno;
            proj[6] = inno;
            proj[7] = inno; } 
        
        else if (model.n == 3) {
            proj[0] = in0;
            proj[1] = in1;
            proj[2] = in2;
            proj[3] = inno;
            proj[4] = inno;
            proj[5] = inno;
            proj[6] = inno;
            proj[7] = inno; } 
        else if (model.n == 4) {
            proj[0] = in0;
            proj[1] = in1;
            proj[2] = in2;
            proj[3] = in3;
            proj[4] = inno;
            proj[5] = inno;
            proj[6] = inno;
            proj[7] = inno; }         
        else if (model.n == 5) {
            proj[0] = in0;
            proj[1] = in1;
            proj[2] = in2;
            proj[3] = in3;
            proj[4] = in4;
            proj[5] = inno;
            proj[6] = inno;
            proj[7] = inno; }         
        else if (model.n == 6) {
            proj[0] = in0;
            proj[1] = in1;
            proj[2] = in2;
            proj[3] = in3;
            proj[4] = in4;
            proj[5] = in5;
            proj[6] = inno;
            proj[7] = inno; }         
        else if (model.n == 7) {
            proj[0] = in0;
            proj[1] = in1;
            proj[2] = in2;
            proj[3] = in3;
            proj[4] = in4;
            proj[5] = in5;
            proj[6] = in6;
            proj[7] = inno; }        
        else if (model.n == 8) {
            proj[0] = in0;
            proj[1] = in1;
            proj[2] = in2;
            proj[3] = in3;
            proj[4] = in4;
            proj[5] = in5;
            proj[6] = in6;
            proj[7] = in7; }
        model.setProjections(proj);
        

        canvas1 = new CanvasIP(model);
        canvas2 = new CanvasOrbPM(model);
        canvas3 = new CanvasOrbPA(model);
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jRadioButton7 = new javax.swing.JRadioButton();
        jRadioButton8 = new javax.swing.JRadioButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton6 = new javax.swing.JRadioButton();
        
        buttonGroup1.add(jRadioButton7);
        buttonGroup1.add(jRadioButton8);
        buttonGroup2.add(jRadioButton5);
        buttonGroup2.add(jRadioButton6);
        
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setSize(new java.awt.Dimension(1400, 800));
        canvas1.setBackground(new Color(255, 255, 255));
        canvas2.setBackground(new java.awt.Color(255, 255, 255));
        canvas3.setBackground(new java.awt.Color(255, 255, 255));
        // canvas1.setVisible(false);
        // jScrollPane2.setBackground(new java.awt.Color(238, 238, 238));
        jLabel2.setText("Pentagram Automaton Orbit"); jLabel2.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel3.setText("Pentagram Map Orbit"); jLabel3.setFont(new java.awt.Font("Helvetica", 0, 12));
        jButton1.setText("Initialize"); jButton1.setFont(new java.awt.Font("Helvetica", 0, 12));
        jButton2.setText("-100"); jButton2.setFont(new java.awt.Font("Helvetica", 0, 10)); 
        jButton4.setText("+100"); jButton4.setFont(new java.awt.Font("Helvetica", 0, 10));
        jButton3.setText("Apply"); jButton3.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextArea1.setText("Specify"); jTextArea1.setFont(new java.awt.Font("Helvetica", 0, 10));
        jTextArea2.setText("ResultPM"); jTextArea2.setFont(new java.awt.Font("Helvetica", 0, 10));
        jTextArea3.setText("ResultPA"); jTextArea3.setFont(new java.awt.Font("Helvetica", 0, 10));
        
        jTextArea1.setEditable(false);
        jTextArea2.setEditable(false);
        jTextArea3.setEditable(false);
        jTextArea1.setLineWrap(true);
        jTextArea2.setLineWrap(true);
        jTextArea3.setLineWrap(true);
        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
//        jTextArea2.setColumns(20);
//        jTextArea2.setRows(5);        
        jTextArea3.setColumns(20);
        jTextArea3.setRows(5);
        
        jScrollPane1.setViewportView(jTextArea3);
        jScrollPane1.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 10, 10, 10, new java.awt.Color(255, 255, 255)));
        jScrollPane2.setViewportView(jTextArea1);
        jScrollPane2.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 10, 10, 10, new java.awt.Color(255, 255, 255)));
        jScrollPane3.setViewportView(jTextArea2);
        jScrollPane3.setBorder(javax.swing.BorderFactory.createMatteBorder(10, 10, 10, 10, new java.awt.Color(255, 255, 255)));

        jLabel1.setText("P2"); jLabel1.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel6.setText("P1"); jLabel6.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel7.setText("P3"); jLabel7.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel8.setText("P4"); jLabel8.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel9.setText("P5"); jLabel9.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel10.setText("P6"); jLabel10.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel11.setText("P7"); jLabel11.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField1.setText(proj[0]); jTextField1.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField2.setText(proj[1]); jTextField2.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField3.setText(proj[2]); jTextField3.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField4.setText(proj[3]); jTextField4.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField5.setText(proj[4]); jTextField5.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField6.setText(proj[5]); jTextField6.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField7.setText(proj[6]); jTextField7.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField8.setText(proj[7]); jTextField8.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel14.setText("P8"); jLabel14.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel4.setText("Input"); jLabel4.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel5.setText("Iterations"); jLabel5.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField9.setText("1000"); jTextField9.setFont(new java.awt.Font("Helvetica", 0, 12));
        jButton5.setText("-1000"); jButton5.setFont(new java.awt.Font("Helvetica", 0, 10));
        jButton6.setText("+1000"); jButton6.setFont(new java.awt.Font("Helvetica", 0, 10));
        jLabel13.setText("Exponent a"); jLabel13.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField10.setText("10"); jTextField10.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel15.setText("Exponent b"); jLabel15.setFont(new java.awt.Font("Helvetica", 0, 12));
        jTextField11.setText("10"); jTextField11.setFont(new java.awt.Font("Helvetica", 0, 12));
        jRadioButton7.setText("0"); jRadioButton7.setFont(new java.awt.Font("Helvetica", 0, 12));
        jRadioButton6.setText("1"); jRadioButton6.setFont(new java.awt.Font("Helvetica", 0, 12));
        jRadioButton8.setText("1"); jRadioButton8.setFont(new java.awt.Font("Helvetica", 0, 12));
        jRadioButton5.setText("2"); jRadioButton5.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel16.setText("Exponentiation"); jLabel16.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel17.setText("Converge to"); jLabel17.setFont(new java.awt.Font("Helvetica", 0, 12));
        jLabel18.setText("Converge to"); jLabel18.setFont(new java.awt.Font("Helvetica", 0, 12));  
        
        jTextField10.setVisible(false);
        jTextField11.setVisible(false);
        jLabel16.setVisible(false);
        jLabel17.setVisible(false);
        jLabel18.setVisible(false);
        jLabel15.setVisible(false);
        jLabel13.setVisible(false);
        jRadioButton7.setVisible(false);
        jRadioButton6.setVisible(false);
        jRadioButton8.setVisible(false);
        jRadioButton5.setVisible(false);

        
        
        
        
        
        
        
        // jTextArea1.setColumns(5);
        // jTextArea1.setRows(5);
        jRadioButton7.setActionCommand("a0");
        jRadioButton6.setActionCommand("a1");
        jRadioButton8.setActionCommand("b1");
        jRadioButton5.setActionCommand("b2");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel4)
                .addGap(232, 232, 232)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(canvas3, javax.swing.GroupLayout.PREFERRED_SIZE, 476, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(canvas2, javax.swing.GroupLayout.PREFERRED_SIZE, 464, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(jLabel16)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jRadioButton6)
                        .addGap(0, 0, 0)
                        .addComponent(jRadioButton5))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel15)
                                    .addComponent(jLabel13))
                                .addGap(29, 29, 29)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField11, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField10, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel17)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jRadioButton7)
                                .addGap(0, 0, 0)
                                .addComponent(jRadioButton8)))
                        .addGap(28, 28, 28)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane3)
                            .addComponent(jScrollPane1))))
                .addGap(35, 35, 35))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(53, 53, 53)
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton6, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel10)
                                    .addGap(18, 18, 18)
                                    .addComponent(jTextField6))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel7)
                                        .addComponent(jLabel9))
                                    .addGap(18, 18, 18)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jTextField5)
                                        .addComponent(jTextField3)
                                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addGap(18, 18, 18)
                                    .addComponent(jTextField1))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel11)
                                    .addGap(18, 18, 18)
                                    .addComponent(jTextField7))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel8)
                                    .addGap(18, 18, 18)
                                    .addComponent(jTextField4))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addGap(18, 18, 18)
                                    .addComponent(jTextField2)))
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(canvas1, javax.swing.GroupLayout.PREFERRED_SIZE, 229, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jTextField1, jTextField2, jTextField3, jTextField4, jTextField5, jTextField6, jTextField7, jTextField8});

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {jButton2, jButton4, jButton5, jButton6});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(canvas1, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jButton1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel9))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel11))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jButton3)
                                .addGap(46, 46, 46))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton5)
                            .addComponent(jButton2)
                            .addComponent(jButton4)
                            .addComponent(jButton6))
                        .addGap(44, 44, 44))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(canvas3, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(canvas2, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel16)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(44, 44, 44)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel13)
                                        .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel17)
                                        .addComponent(jRadioButton7)
                                        .addComponent(jRadioButton8))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel15)
                                        .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel18)
                                        .addComponent(jRadioButton6)
                                        .addComponent(jRadioButton5))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(25, 25, 25))))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {jTextField1, jTextField2, jTextField3, jTextField4, jTextField5, jTextField6, jTextField7, jTextField8});

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {canvas2, canvas3});

        pack();
    

    }
    
    void reset() {
        canvas1.repaint();
        canvas2.repaint();
        canvas3.repaint();
    }
    void addRadioListener(ActionListener click) {
        jRadioButton7.addActionListener(click);
        jRadioButton6.addActionListener(click);
        jRadioButton8.addActionListener(click);
        jRadioButton5.addActionListener(click);
    }
    
    
    void addClickListener(ActionListener click) {
        jButton1.addActionListener(click);
    } 
    
    void addIterationListener(ActionListener click) {
        jTextField9.addActionListener(click);       
    }

    public String getRadiosenderA() {
        String radio1 = buttonGroup1.getSelection().getActionCommand();
        return radio1;
    }    
    
    public String getRadiosenderB() {
        String radio2 = buttonGroup2.getSelection().getActionCommand();
        return radio2;
    }
    
    public String getIteration() {
        String itnew = jTextField9.getText();
        return itnew;
    }    
    
    public String getexpa() {
        String newexpa = jTextField10.getText();
        return newexpa;
    }    
    
    public String getexpb() {
        String newexpb = jTextField11.getText();
        return newexpb;
    }
    
    void addExpListenerA(ActionListener click) {
        jTextField10.addActionListener(click);       
    }    
    
    void addExpListenerB(ActionListener click) {
        jTextField11.addActionListener(click);       
    }
    
    void addIterationListener100p(ActionListener click) {
        jButton4.addActionListener(click);       
    }    
    void addIterationListener100m(ActionListener click) {
        jButton2.addActionListener(click);       
    }    
    
    void addIterationListener1000p(ActionListener click) {
        jButton6.addActionListener(click);       
    }    
    void addIterationListener1000m(ActionListener click) {
        jButton5.addActionListener(click);       
    }    
    
    void addProListener(ActionListener click) {
        jButton3.addActionListener(click);       
    }    
    
    public String[] getinitProj() {
        return proj;
    }
    
    public String[] getProjections() {
            String in0 = jTextField1.getText();
            proj[0] = in0;
            if (model.n == 2) {
            String in1 = jTextField2.getText();
            proj[1] = in1; } 
            if (model.n == 3)  {
            String in1 = jTextField2.getText();
            proj[1] = in1;    
            String in2 = jTextField3.getText();
            proj[2] = in2; } 
            if (model.n == 4) {
            String in1 = jTextField2.getText();
            proj[1] = in1;    
            String in2 = jTextField3.getText();
            proj[2] = in2;                
            String in3 = jTextField4.getText();
            proj[3] = in3; } 
            if (model.n == 5) {
            String in1 = jTextField2.getText();
            proj[1] = in1;    
            String in2 = jTextField3.getText();
            proj[2] = in2;                
            String in4 = jTextField5.getText();
            proj[4] = in4;
            String in3 = jTextField4.getText();
            proj[3] = in3;
            } 
            if (model.n == 6) {
            String in1 = jTextField2.getText();
            proj[1] = in1;    
            String in2 = jTextField3.getText();
            proj[2] = in2;                
            String in4 = jTextField5.getText();
            proj[4] = in4;
            String in3 = jTextField4.getText();
            proj[3] = in3;                
            String in5 = jTextField6.getText();
            proj[5] = in5; } 
            if (model.n == 7) {
            String in1 = jTextField2.getText();
            proj[1] = in1;    
            String in2 = jTextField3.getText();
            proj[2] = in2;                
            String in4 = jTextField5.getText();
            proj[4] = in4;
            String in3 = jTextField4.getText();
            proj[3] = in3;                
            String in5 = jTextField6.getText();
            proj[5] = in5;                
            String in6 = jTextField7.getText();
            proj[6] = in6; } 
            if (model.n == 8) {
            String in1 = jTextField2.getText();
            proj[1] = in1;    
            String in2 = jTextField3.getText();
            proj[2] = in2;                
            String in4 = jTextField5.getText();
            proj[4] = in4;
            String in3 = jTextField4.getText();
            proj[3] = in3;                
            String in5 = jTextField6.getText();
            proj[5] = in5;                
            String in6 = jTextField7.getText();
            proj[6] = in6;                
            String in7 = jTextField8.getText();
            proj[7] = in7;  } 
            return proj;
    }
        
    void setOutput(String matrix, String resultPA, String resultPM) {
        jTextArea3.setText(resultPA);
        jTextArea2.setText(resultPM);
        jTextArea1.setText(matrix);
        // jLabel13.setText(specify);
        // jLabel4.setText(matrix);
    }
    

    
                                        

                                           

                                           

     
    
}
