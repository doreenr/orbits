/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package universal;

/**
 *
 * @author Doreen
 */

import java.applet.Applet;
import java.awt.event.*;
import java.awt.*;

/*This class does the basic arithmetic
  of vectors up to length 20*/
public class Vektor {
    double[] x=new double[20];
    int size;

    public Vektor(){}
    /*constructors*/

    public Vektor(Complex z) {
	size=3;
	x[0]=z.x;
	x[1]=z.y;
	x[2]=1.0;
    }

    public Vektor(double a0,double a1,double a2) {
	size=3;
	x[0]=a0;
	x[1]=a1;
	x[2]=a2;
    }

    public Vektor(double[] X) {
	size=X.length;
	for(int i=0;i<size;++i) x[i]=X[i];
    }

    public Vektor(int[] X) {
	size=X.length;
	for(int i=0;i<size;++i) x[i]=X[i];
    }

    public Vektor(Vektor V) {
	size=V.size;
	for(int i=0;i<size;++i) x[i]=V.x[i];
    }

    //public Vektor(LongVector V) {
	//size=3;
	//for(int i=0;i<size;++i) x[i]=V.x[i];
    //}


    public Vektor(int s) {
	this.size=s;
	for(int i=0;i<size;++i) this.x[i]=0;
    }


    /**a random vector*/

    public static Vektor random(int s) {
	Vektor m=new Vektor();
	m.size=s;
	for(int i=0;i<s;++i) {
	  m.x[i]=Math.random();
	}
	return(m);
    }
    public static Vektor random2(int s) {
	Vektor m=new Vektor();
	m.size=s;
	for(int i=0;i<s;++i) {
	  m.x[i]=Math.random()-.5;
	}
	return(m);
    }

    /**A random vector with integer entries between -N and N*/

    public static Vektor randomInt(int s,int N) {
	Vektor m=random(s);
	for(int i=0;i<s;++i) {
	  m.x[i]=Math.floor(2*N*m.x[i]-N);
	}
	return(m);
    }


    /**We should have q0<q1*/

    public Vektor coordinateSwap(int q0,int q1) {

	if(q1<=q0) return(null);

	Vektor V=new Vektor(this);
	if((q0==0)&&(q1==1)) return(V);

	if(q0==0) {
	    V.x[1]=x[q1];
	    V.x[q1]=x[1];
	    return(V);
	}
	if(q0==1) {
	    V.x[0]=x[q1];
	    V.x[q1]=x[0];
	    return(V);
	}
	V.x[0]=this.x[q0]; 
	V.x[1]=this.x[q1]; 
	V.x[q0]=this.x[0]; 
	V.x[q1]=this.x[1]; 
	return(V);
    }

    /**Here are some routines specially for 3D vectors*/

    public static Vektor cross(Vektor v,Vektor w) {
	if(v.size!=3) return(null);
	if(w.size!=3) return(null);
	Vektor X=new Vektor();
	X.x[0]=v.x[1]*w.x[2]-w.x[1]*v.x[2];
	X.x[1]=v.x[2]*w.x[0]-w.x[2]*v.x[0];
	X.x[2]=v.x[0]*w.x[1]-w.x[0]*v.x[1];
	X.size=3;
	return(X);
    }


    public static Vektor findCross(Vektor v1,Vektor v2,Vektor v3,Vektor v4) {
	if(v1.size!=3) return(null);
	if(v2.size!=3) return(null);
	if(v3.size!=3) return(null);
	if(v4.size!=3) return(null);
	Vektor v5=cross(v1,v2);
	Vektor v6=cross(v3,v4);
	Vektor v7=cross(v5,v6);
	return(v7);
    }


    /**Here are some general routines**/


    public static Vektor plus(Vektor v1,Vektor v2) {
	if(v1.size!=v2.size) return(null);
	Vektor w=new Vektor();
	for(int i=0;i<v1.size;++i) w.x[i]=v1.x[i]+v2.x[i];
	w.size=v1.size;
	return(w);
    }

    public static Vektor minus(Vektor v1,Vektor v2) {
	if(v1.size!=v2.size) return(null);
	Vektor w=new Vektor();
	for(int i=0;i<v1.size;++i) w.x[i]=v1.x[i]-v2.x[i];
	w.size=v1.size;
	return(w);
    }

    public static Vektor scale(double r,Vektor v) {
	Vektor w=new Vektor();
	for(int i=0;i<v.size;++i) w.x[i]=r*v.x[i];
	w.size=v.size;
	return(w);
    }

    public Vektor scale(double r) {
	return(scale(r,this));
    }

    public static Vektor interpolate(double s,Vektor V1,Vektor V2) {
	Vektor W1=scale((1-s),V1);
	Vektor W2=scale(s,V2);
	Vektor W3=plus(W1,W2);
	return(W3);
    }


    public static double dot(Vektor v,Vektor w) {
	int s=v.size;
	double d=0;
	for(int i=0;i<s;++i) d=d+v.x[i]*w.x[i];
	return(d);
    }

    public double norm() {
	return(Math.sqrt(dot(this,this)));
    }

    public double norm2() {
	double s=0;
	for(int i=0;i<size;++i) {
	    double t=Math.abs(x[i]);
	    if(s<t) s=t;
	}
	return(s);
    }

    public Vektor unit() {
	double t=this.norm();
	t=Math.sqrt(t);
	Vektor V=Vektor.scale(1/t,this);
	return(V);
    }

    public static double dist(Vektor v,Vektor w) {
	Vektor x=minus(v,w);
	return(x.norm());
    }


    /**This does Gram schmidt to a pair of vectors**/

    public static Vektor[] ortho(Vektor[] V) {
	Vektor[] W=new Vektor[2];
	W[0]=new Vektor(V[0]);
	double x=W[0].norm();
	W[0]=scale(1/x,W[0]);
	W[1]=new Vektor(V[1]);
	W[1]=minus(W[1],scale(dot(W[0],W[1]),W[0]));
	return(W);
    }


    /**This takes the minimum of two vectors*/

    public static Vektor min(Vektor V1,Vektor V2) {
	if(V1.size!=V2.size) return(null);
	Vektor W=new Vektor(V1.size);
	for(int i=0;i<V1.size;++i) W.x[i]=Math.min(V1.x[i],V2.x[i]);
	return(W);
    }

    /**This takes the maximum of two vectors*/

    public static Vektor max(Vektor V1,Vektor V2) {
	if(V1.size!=V2.size) return(null);
	Vektor W=new Vektor(V1.size);
	for(int i=0;i<V1.size;++i) W.x[i]=Math.max(V1.x[i],V2.x[i]);
	return(W);
    }



    public void print() {
	for(int i=0;i<size;++i)	{
	    double d=nearInt(x[i]);
	    System.out.print(d+" ");
	}
	System.out.println("");
    }


    public static double nearInt(double s) {
	for(int i=-1000;i<1000;++i) {
	    if(Math.abs(s-i)<.000000000001) return(i);
	}
	return(s);
    }


    public static double latticeDist(Vektor V) {
	double max=0;
	for(int i=0;i<4;++i) {
	    double test=latticeDist(V.x[i]);
	    if(max<test) max=test;
	}
	return(max);
    }


    public static double latticeDist(double x) {
	double min=1;
	for(int i=-10;i<10;++i) {
	    double test=Math.abs(x-i);
	    if(test<min) min=test;
	}
	return(min);
    }

    public Complex toComplex() {
	Complex z=new Complex(x[0],x[1]);
	return(z);
    }

}
