/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package universal;

import java.math.BigDecimal;

/**
 *
 * @author Doreen
 */
public class Orbit {
    
    private int iteration;
    private Complex[] d2;
    private BigDecimal[][] bM; // rows, columns
    
    public Orbit(Complex[] d, int it) {
        iteration = it;
        d2 = d;
    }    
    
    public Orbit(int it) {
        iteration = it;
    }
    
    public BigDecimal[][] BigPentMapOrbitX(BigDecimal[] bigxn, BigDecimal[] bigyn) {
        int n = bigxn.length;
        bM = new BigDecimal[iteration][n];
        BigDecimal xread[] = new BigDecimal[n]; // Länge: Vertices
        BigDecimal yread[] = new BigDecimal[n];
        BigDecimal xresult[] = new BigDecimal[n];
        BigDecimal yresult[] = new BigDecimal[n];
        BigDecimal one = new BigDecimal("1");
        for (int i = 0; i < n; ++i) {
            xread[i] = bigxn[i];
            yread[i] = bigyn[i]; }
        for (int k = 0; k < iteration; ++k) { // ITERATION
            for (int i = 0; i < n; ++i){ // VERTICES
                int index1, index2, index3, index4;
                BigDecimal tempadd1, tempadd2, tempadd3, tempadd4, max1, max2, max3, max4;
                index1 = ((i-1) % n + n) % n;
                // System.out.println("index1 " + index1 + ", xread.length " + xread.length);
                // System.out.println("index1 " + index1 + ", yread.length " + yread.length);
                index2 = ((i+1) % n + n) % n;
                index3 = ((i+2) % n + n) % n;
                index4 = ((i) % n + n) % n; 
                tempadd1 = one.subtract(xread[index1].multiply(yread[index1]));
                tempadd2 = one.subtract(xread[index2].multiply(yread[index2]));
                tempadd3 = one.subtract(xread[index3].multiply(yread[index3]));
                tempadd4 = one.subtract(xread[index4].multiply(yread[index4]));
                xresult[i] = xread[index4].multiply((tempadd1.divide(tempadd2, 1, BigDecimal.ROUND_HALF_UP)));
                yresult[i] = xread[index2].multiply((tempadd3.divide(tempadd4, 1, BigDecimal.ROUND_HALF_UP)));
                bM[k][i] = xresult[i];  
                xread[i] = xresult[i];
                yread[i] = yresult[i]; }
        }
        return bM; 
    }
    
        public BigDecimal[][] BigPentMapOrbitY(BigDecimal[] bigxn, BigDecimal[] bigyn) {
        int n = bigxn.length;
        bM = new BigDecimal[iteration][n];
        BigDecimal xread[] = new BigDecimal[n]; // Länge: Vertices
        BigDecimal yread[] = new BigDecimal[n];
        BigDecimal xresult[] = new BigDecimal[n];
        BigDecimal yresult[] = new BigDecimal[n];
        BigDecimal one = new BigDecimal("1");
        for (int i = 0; i < n; ++i) {
            xread[i] = bigxn[i];
            yread[i] = bigyn[i]; }
        for (int k = 0; k < iteration; ++k) { // ITERATION
            for (int i = 0; i < n; ++i){ // VERTICES
                int index1, index2, index3, index4;
                BigDecimal tempadd1, tempadd2, tempadd3, tempadd4, max1, max2, max3, max4;
                index1 = ((i-1) % n + n) % n;
                // System.out.println("index1 " + index1 + ", xread.length " + xread.length);
                // System.out.println("index1 " + index1 + ", yread.length " + yread.length);
                index2 = ((i+1) % n + n) % n;
                index3 = ((i+2) % n + n) % n;
                index4 = ((i) % n + n) % n; 
                tempadd1 = one.subtract(xread[index1].multiply(yread[index1]));
                tempadd2 = one.subtract(xread[index2].multiply(yread[index2]));
                tempadd3 = one.subtract(xread[index3].multiply(yread[index3]));
                tempadd4 = one.subtract(xread[index4].multiply(yread[index4]));
                xresult[i] = xread[index4].multiply((tempadd1.divide(tempadd2, 1, BigDecimal.ROUND_HALF_UP)));
                yresult[i] = xread[index2].multiply((tempadd3.divide(tempadd4, 1, BigDecimal.ROUND_HALF_UP)));
                bM[k][i] = yresult[i];  
                xread[i] = xresult[i];
                yread[i] = yresult[i]; }
        }
        return bM;    
        
    } 
    public BigDecimal[][] BigPentAutOrbitX(BigDecimal[] bigxn, BigDecimal[] bigyn) {
        int n = bigxn.length;
        bM = new BigDecimal[iteration][n];
        BigDecimal xread[] = new BigDecimal[n]; // Länge: Vertices
        BigDecimal yread[] = new BigDecimal[n];
        BigDecimal xresult[] = new BigDecimal[n];
        BigDecimal yresult[] = new BigDecimal[n];
        for (int i = 0; i < n; ++i) {
            xread[i] = bigxn[i];
            yread[i] = bigyn[i]; }
        for (int k = 0; k < iteration; ++k) { // ITERATION
            for (int i = 0; i < n; ++i){ // VERTICES
                int index1, index2, index3, index4;
                BigDecimal zero, tempadd1, tempadd2, tempadd3, tempadd4, max1, max2, max3, max4;
                index1 = ((i-1) % n + n) % n;
                // System.out.println("index1 " + index1 + ", xread.length " + xread.length);
                // System.out.println("index1 " + index1 + ", yread.length " + yread.length);
                index2 = ((i+1) % n + n) % n;
                index3 = ((i+2) % n + n) % n;
                index4 = ((i) % n + n) % n;
                tempadd1 = xread[index1].add(yread[index1]);
                tempadd2 = xread[index2].add(yread[index2]);
                tempadd3 = xread[index3].add(yread[index3]);
                tempadd4 = xread[index4].add(yread[index4]);
                zero = new BigDecimal("0");
                max1 = tempadd1.max(zero);
                max2 = tempadd2.max(zero);
                max3 = tempadd3.max(zero);
                max4 = tempadd4.max(zero);
                xresult[i] = (xread[index4].add(max1)).subtract(max2);
                yresult[i] = (yread[index2].add(max3)).subtract(max4);
                bM[k][i] = xresult[i];  
                xread[i] = xresult[i];
                yread[i] = yresult[i]; }
        }
        return bM; 
    }
    
    public BigDecimal[][] BigPentAutOrbitY(BigDecimal[] bigxn, BigDecimal[] bigyn) {
        int n = bigxn.length;
        bM = new BigDecimal[iteration][n];
        BigDecimal xread[] = new BigDecimal[n]; // Länge: Vertices
        BigDecimal yread[] = new BigDecimal[n];
        BigDecimal xresult[] = new BigDecimal[n];
        BigDecimal yresult[] = new BigDecimal[n];
        BigDecimal zero = new BigDecimal("0");
        for (int i = 0; i < n; ++i) {
            xread[i] = bigxn[i];
            yread[i] = bigyn[i]; }
        for (int k = 0; k < iteration; ++k) { // ITERATION
            for (int i = 0; i < n; ++i){ // VERTICES
                int index1, index2, index3, index4;
                BigDecimal tempadd1, tempadd2, tempadd3, tempadd4, max1, max2, max3, max4;
                index1 = ((i-1) % n + n) % n;
                index2 = ((i+1) % n + n) % n;
                index3 = ((i+2) % n + n) % n;
                index4 = ((i) % n + n) % n;
                tempadd1 = xread[index1].add(yread[index1]);
                tempadd2 = xread[index2].add(yread[index2]);
                tempadd3 = xread[index3].add(yread[index3]);
                tempadd4 = xread[index4].add(yread[index4]);
                
                max1 = tempadd1.max(zero);
                max2 = tempadd2.max(zero);
                max3 = tempadd3.max(zero);
                max4 = tempadd4.max(zero);
                xresult[i] = (xread[index4].add(max1)).subtract(max2);
                yresult[i] = (yread[index2].add(max3)).subtract(max4);
                bM[k][i] = yresult[i];  
                xread[i] = xresult[i];
                yread[i] = yresult[i]; 
            }
        }
        return bM; 
    }
        
    public MMatrix PentAutOrbitX() {
        int n = d2.length;
        MMatrix Mx = new MMatrix(iteration, n); 
        double xread[] = new double[n]; // Länge: Vertices
        double yread[] = new double[n];
        double xresult[] = new double[n];
        double yresult[] = new double[n];
        for (int i = 0; i < n; ++i) {
            xread[i] = d2[i].x;
            yread[i] = d2[i].y; }
        for (int k = 0; k < Mx.rows; ++k) { // ITERATION
            for (int i = 0; i < n; ++i){ // VERTICES
                double tempadd1, tempadd2, tempadd3, tempadd4, max1, max2, max3, max4;
                tempadd1 = xread[((i-1) % n + n) % n] + yread[((i-1) % n + n) % n];
                tempadd2 = xread[((i+1) % n + n) % n] + yread[((i+1) % n + n) % n];
                tempadd3 = xread[((i+2) % n + n) % n] + yread[((i+2) % n + n) % n];
                tempadd4 = xread[((i) % n + n) % n] + yread[((i) % n + n) % n];
                max1 = Math.max(0, tempadd1);
                max2 = Math.max(0, tempadd2);
                max3 = Math.max(0, tempadd3);
                max4 = Math.max(0, tempadd4);
                xresult[i] = xread[((i) % n + n) % n] + max1 - max2;
                yresult[i] = yread[((i+1) % n + n) % n] + max3 - max4;
                Mx.element[k][i] = xresult[i];  
                xread[i] = xresult[i];
                yread[i] = yresult[i]; }
        }
        return Mx; 
    }     
    
    public MMatrix PentAutOrbitY() {
        int n = d2.length;
        MMatrix My = new MMatrix(iteration, n);
        double xread[] = new double[n]; // Länge: Vertices
        double yread[] = new double[n];
        double xresult[] = new double[n];
        double yresult[] = new double[n];
        for (int i = 0; i < n; ++i) {
            xread[i] = d2[i].x;
            yread[i] = d2[i].y;
        }
        for (int k = 0; k < My.rows; ++k) { // ITERATION
            for (int i = 0; i < n; ++i){ // VERTICES
                double tempadd1, tempadd2, tempadd3, tempadd4, max1, max2, max3, max4;
                tempadd1 = xread[((i-1) % n + n) % n] + yread[((i-1) % n + n) % n];
                tempadd2 = xread[((i+1) % n + n) % n] + yread[((i+1) % n + n) % n];
                tempadd3 = xread[((i+2) % n + n) % n] + yread[((i+2) % n + n) % n];
                tempadd4 = xread[((i) % n + n) % n] + yread[((i) % n + n) % n];
                max1 = Math.max(0, tempadd1);
                max2 = Math.max(0, tempadd2);
                max3 = Math.max(0, tempadd3);
                max4 = Math.max(0, tempadd4);
                xresult[i] = xread[((i) % n + n) % n] + max1 - max2;
                yresult[i] = yread[((i+1) % n + n) % n] + max3 - max4;
                My.element[k][i] = yresult[i];                
                xread[i] = xresult[i];
                yread[i] = yresult[i];
            }
        }
        return My; 
    }  
    
    public MMatrix PentMapOrbitX() {
        int n = d2.length;
        MMatrix Mx = new MMatrix(iteration, n); 
        double xread[] = new double[n]; // Länge: Vertices
        double yread[] = new double[n];
        double xresult[] = new double[n];
        double yresult[] = new double[n];
        for (int i = 0; i < (Mx.columns); ++i) {
            xread[i] = d2[i].x;
            yread[i] = d2[i].y;        }
        for (int k = 0; k < Mx.rows; ++k) { // ITERATION
            for (int i = 0; i < Mx.columns; ++i){ // VERTICES
                double tempadd1, tempadd2, tempadd3, tempadd4;
                tempadd1 = 1 - xread[((i-1) % n + n) % n] * yread[((i-1) % n + n) % n];
                tempadd2 = 1 - xread[((i+1) % n + n) % n] * yread[((i+1) % n + n) % n];
                tempadd3 = 1 - xread[((i+2) % n + n) % n] * yread[((i+2) % n + n) % n];
                tempadd4 = 1 - xread[((i) % n + n) % n] * yread[((i) % n + n) % n]; 
                xresult[i] = xread[i] * (tempadd1/tempadd2);
                yresult[i] = yread[((i+1) % n + n) % n] * (tempadd3/tempadd4);  
                Mx.element[k][i] = xresult[i];  
                xread[i] = xresult[i];
                yread[i] = yresult[i]; }
        }
        return Mx;
    }      
    
    public MMatrix PentMapOrbitY() {
        int n = d2.length;
        MMatrix My = new MMatrix(iteration, n); 
        double xread[] = new double[n]; // Länge: Vertices
        double yread[] = new double[n];
        double xresult[] = new double[n];
        double yresult[] = new double[n];
        for (int i = 0; i < (My.columns); ++i) {
            xread[i] = d2[i].x;
            yread[i] = d2[i].y;        }
        for (int k = 0; k < My.rows; ++k) { // ITERATION
            for (int i = 0; i < My.columns; ++i){ // VERTICES
                double tempadd1, tempadd2, tempadd3, tempadd4;
                tempadd1 = 1 - xread[((i-1) % n + n) % n] * yread[((i-1) % n + n) % n];
                tempadd2 = 1 - xread[((i+1) % n + n) % n] * yread[((i+1) % n + n) % n];
                tempadd3 = 1 - xread[((i+2) % n + n) % n] * yread[((i+2) % n + n) % n];
                tempadd4 = 1 - xread[((i) % n + n) % n] * yread[((i) % n + n) % n]; 
                xresult[i] = xread[i] * (tempadd1/tempadd2);
                yresult[i] = yread[((i+1) % n + n) % n] * (tempadd3/tempadd4);  
                My.element[k][i] = yresult[i];  
                xread[i] = xresult[i];
                yread[i] = yresult[i]; }
        }
        return My;
    }   
}





