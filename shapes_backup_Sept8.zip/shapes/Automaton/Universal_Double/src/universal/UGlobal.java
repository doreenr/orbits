/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package universal;

/**
 *
 * @author Doreen
 */
public class UGlobal {

    public UGlobal() {
    UModel model  = new UModel();
    UView view = new UView(model);
    new UController(view, model);
    view.setVisible(true);
  }
    
}
