/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package universal;

import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/**
 *
 * @author Doreen
 */
public class Coord {
    private static Complex[] c = randomCoordsCircle(5);
    Complex[] pi2;  
    
    public Coord() {}
    
    // public static Complex[] getCrossRatio() {  }
    
    // call from both canvases
    public static Complex[] getInstance() {
        return c;
    }
    
    private static Complex[] randomCoords(int n) {
        final Complex[] results = new Complex[n];
        for(int i = 0; i < results.length; i++){         
            results[i] = new Complex(200 * Math.random(), 200 * Math.random());            
        }         
        return results;    
    }
    
    private static Complex[] randomCoordsCircle(int n) {
        final Complex[] pi2 = new Complex[n];
        double pi1, x, y;
        ArrayList<Double> pilist = new ArrayList();
        for(int i=0; i < pi2.length; i++) {
            pi1 = 2 * Math.PI * Math.random();
            pilist.add(pi1);
        }
        Collections.sort(pilist);        
        for (int i = 0; i < n; i++) {
            x = 100 + (60.0 * Math.cos(pilist.get(i))); // 100 = w/2
            y = 100 + (60.0 * Math.sin(pilist.get(i))); // 100 = h/2
            pi2[i] = new Complex(x,y);
        }
        return pi2;
    }
    
    // Creates a random convex n-gon with vertices on a circle
    public Complex[] randCoordCircle(int n, String size) {
        pi2 = new Complex[n];
        double pi1, x, y;
        ArrayList<Double> pilist = new ArrayList();
        for(int i=0; i < pi2.length; i++) {
            pi1 = 2 * Math.PI * Math.random();
            pilist.add(pi1);
        }
        Collections.sort(pilist);  
        int s = 60;
        if (size == "small") {
            s = 10;
        }
        else {}
        for (int i = 0; i < n; i++) {
            x = 100 + (s * Math.cos(pilist.get(i))); // 100 = w/2
            y = 100 + (s * Math.sin(pilist.get(i))); // 100 = h/2
            pi2[i] = new Complex(x,y);
        }
        return pi2;
    }
    
        public Complex[] randCoordCircleCCW(int n, String size) {
        pi2 = new Complex[n];
        double pi1, x, y;
        ArrayList<Double> pilist = new ArrayList();
        for(int i=0; i < pi2.length; i++) {
            pi1 = 2 * Math.PI * Math.random();
            pilist.add(pi1);
        }
        Collections.sort(pilist, Collections.reverseOrder());  
        int s = 60;
        if (size == "small") {
            s = 10;
        }
        else {}
        for (int i = 0; i < n; i++) {
            x = 100 + (s * Math.cos(pilist.get(i))); // 100 = w/2
            y = 100 + (s * Math.sin(pilist.get(i))); // 100 = h/2
            pi2[i] = new Complex(x,y);
        }
        return pi2;
    }
    
    
    public Point2D.Double getIntersectionPoint(Line2D.Double line1, Line2D.Double line2) {
    if (! line1.intersectsLine(line2) ) return null;
      double px = line1.getX1(),
            py = line1.getY1(),
            rx = line1.getX2()-px,
            ry = line1.getY2()-py;
      double qx = line2.getX1(),
            qy = line2.getY1(),
            sx = line2.getX2()-qx,
            sy = line2.getY2()-qy;

      double det = sx*ry - sy*rx;
      if (det == 0) {
        return null;
      } else {
        double z = (sx*(qy-py)+sy*(px-qx))/det;
        if (z==0 ||  z==1) return null;  // intersection at end point!
        return new Point2D.Double(
          (double)(px+z*rx), (double)(py+z*ry));
      }
    
}
    
}
    
