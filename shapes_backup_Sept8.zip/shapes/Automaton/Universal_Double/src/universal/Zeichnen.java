/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package universal;

import java.awt.AlphaComposite;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.math.BigDecimal;

/**
 *
 * @author Doreen
 */
public class Zeichnen extends Canvas {
    
    private Color turq  = new Color( 0,  153, 153);    
    int[] px;
    int[] py;
    int np;
    
    public Zeichnen() {}
    
    public void ZeichneBigOrbit(Graphics2D g, BigDecimal[][] Mx, BigDecimal[][] My, String[] proj, double pointsize) {

    for (int i = 1; i < proj.length; ++i) { 
        if (proj[i].matches("-")) {
        // System.out.println("i " + i);
        np = i;
        break;
        } 
        else { np = 8; }
    }
    px = new int[np];
    py = new int[np];
    for (int i = 0; i < np; ++i) { 
        px[i] = Integer.parseInt(proj[i].substring(1,2));  
        py[i] = Integer.parseInt(proj[i].substring(3,4)); 
        // System.out.println("px " + px[i] + ", py " + py[i]);
    }
    float alpha = 0.3F;
    g.setComposite(makeComposite(alpha));
    int mxcolumns = Mx[0].length; // columns
    int mxrows = Mx.length; // rows
//    System.out.println("mx columns " + mxcolumns + ", iteration " + mxrows);
//    System.out.println("Mx[0][0] " + Mx[0][0] + ", My[0][0] " + My[0][0]);
//    System.out.println("px[0] " + px[0] + ", py[0] " + py[0]);
    Double plotdoublex;
    Double plotdoubley;
    
        for (int j = 0; j < mxrows; ++j) {
            if (mxcolumns == 1) {
            plotdoublex = Mx[j][px[0]].doubleValue();
            plotdoubley = My[j][py[0]].doubleValue();
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ);
            }            
            else if (mxcolumns == 2) {
            plotdoublex = Mx[j][px[0]].doubleValue();
            plotdoubley = My[j][py[0]].doubleValue();                
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ);
            plotdoublex = Mx[j][px[1]].doubleValue();
            plotdoubley = My[j][py[1]].doubleValue();  
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            }            
            else if (mxcolumns == 3) {
            plotdoublex = Mx[j][px[0]].doubleValue();
            plotdoubley = My[j][py[0]].doubleValue();                
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ);
            plotdoublex = Mx[j][px[1]].doubleValue();
            plotdoubley = My[j][py[1]].doubleValue();  
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            plotdoublex = Mx[j][px[2]].doubleValue();
            plotdoubley = My[j][py[2]].doubleValue();  
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            }
            else if (mxcolumns == 4) {
            plotdoublex = Mx[j][px[0]].doubleValue();
            plotdoubley = My[j][py[0]].doubleValue();                
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ);
            plotdoublex = Mx[j][px[1]].doubleValue();
            plotdoubley = My[j][py[1]].doubleValue();  
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            plotdoublex = Mx[j][px[2]].doubleValue();
            plotdoubley = My[j][py[2]].doubleValue();  
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            plotdoublex = Mx[j][px[3]].doubleValue();
            plotdoubley = My[j][py[3]].doubleValue(); 
            g.setColor(Color.MAGENTA);
            Ellipse2D.Double circ4 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ4);
            }            
            else if (mxcolumns == 5) {
            plotdoublex = Mx[j][px[0]].doubleValue();
            plotdoubley = My[j][py[0]].doubleValue();                
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ);
            plotdoublex = Mx[j][px[1]].doubleValue();
            plotdoubley = My[j][py[1]].doubleValue();  
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            plotdoublex = Mx[j][px[2]].doubleValue();
            plotdoubley = My[j][py[2]].doubleValue();  
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            plotdoublex = Mx[j][px[3]].doubleValue();
            plotdoubley = My[j][py[3]].doubleValue(); 
            g.setColor(Color.MAGENTA);
            Ellipse2D.Double circ4 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ4);
            plotdoublex = Mx[j][px[4]].doubleValue();
            plotdoubley = My[j][py[4]].doubleValue();             
            g.setColor(turq);
            Ellipse2D.Double circ5 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ5);
            }
            else if (mxcolumns == 6) {
            plotdoublex = Mx[j][px[0]].doubleValue();
            plotdoubley = My[j][py[0]].doubleValue();                
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ);
            plotdoublex = Mx[j][px[1]].doubleValue();
            plotdoubley = My[j][py[1]].doubleValue();  
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            plotdoublex = Mx[j][px[2]].doubleValue();
            plotdoubley = My[j][py[2]].doubleValue();  
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            plotdoublex = Mx[j][px[3]].doubleValue();
            plotdoubley = My[j][py[3]].doubleValue(); 
            g.setColor(Color.MAGENTA);
            Ellipse2D.Double circ4 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ4);
            plotdoublex = Mx[j][px[4]].doubleValue();
            plotdoubley = My[j][py[4]].doubleValue();             
            g.setColor(turq);
            Ellipse2D.Double circ5 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ5);
            plotdoublex = Mx[j][px[5]].doubleValue();
            plotdoubley = My[j][py[5]].doubleValue();   
            g.setColor(Color.yellow);
            Ellipse2D.Double circ6 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ6);
            }
            else if (mxcolumns == 7) {
            plotdoublex = Mx[j][px[0]].doubleValue();
            plotdoubley = My[j][py[0]].doubleValue();                
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ);
            plotdoublex = Mx[j][px[1]].doubleValue();
            plotdoubley = My[j][py[1]].doubleValue();  
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            plotdoublex = Mx[j][px[2]].doubleValue();
            plotdoubley = My[j][py[2]].doubleValue();  
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            plotdoublex = Mx[j][px[3]].doubleValue();
            plotdoubley = My[j][py[3]].doubleValue(); 
            g.setColor(Color.MAGENTA);
            Ellipse2D.Double circ4 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ4);
            plotdoublex = Mx[j][px[4]].doubleValue();
            plotdoubley = My[j][py[4]].doubleValue();             
            g.setColor(turq);
            Ellipse2D.Double circ5 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ5);
            plotdoublex = Mx[j][px[5]].doubleValue();
            plotdoubley = My[j][py[5]].doubleValue();   
            g.setColor(Color.yellow);
            Ellipse2D.Double circ6 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ6);
            plotdoublex = Mx[j][px[6]].doubleValue();
            plotdoubley = My[j][py[6]].doubleValue(); 
            g.setColor(Color.GREEN);
            Ellipse2D.Double circ7 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ7);
            }
            else if (mxcolumns == 8) {
            plotdoublex = Mx[j][px[0]].doubleValue();
            plotdoubley = My[j][py[0]].doubleValue();                
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ);
            plotdoublex = Mx[j][px[1]].doubleValue();
            plotdoubley = My[j][py[1]].doubleValue();  
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            plotdoublex = Mx[j][px[2]].doubleValue();
            plotdoubley = My[j][py[2]].doubleValue();  
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            plotdoublex = Mx[j][px[3]].doubleValue();
            plotdoubley = My[j][py[3]].doubleValue(); 
            g.setColor(Color.MAGENTA);
            Ellipse2D.Double circ4 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ4);
            plotdoublex = Mx[j][px[4]].doubleValue();
            plotdoubley = My[j][py[4]].doubleValue();             
            g.setColor(turq);
            Ellipse2D.Double circ5 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ5);
            plotdoublex = Mx[j][px[5]].doubleValue();
            plotdoubley = My[j][py[5]].doubleValue();   
            g.setColor(Color.yellow);
            Ellipse2D.Double circ6 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ6);
            plotdoublex = Mx[j][px[6]].doubleValue();
            plotdoubley = My[j][py[6]].doubleValue(); 
            g.setColor(Color.GREEN);
            Ellipse2D.Double circ7 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ7);
            plotdoublex = Mx[j][px[7]].doubleValue();
            plotdoubley = My[j][py[7]].doubleValue(); 
            g.setColor(Color.DARK_GRAY);
            Ellipse2D.Double circ8 = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize); g.fill(circ8);
            }            
        } 
    }
    
    public void ZeichneOrbit(Graphics2D g, MMatrix Mx, MMatrix My, String[] proj, double pointsize) {
  
    for (int i = 1; i < proj.length; ++i) { 
        if (proj[i].matches("-")) {
        // System.out.println("i " + i);
        np = i;
        break;
        } 
    }
    px = new int[np];
    py = new int[np];
    for (int i = 0; i < np; ++i) { 
        px[i] = Integer.parseInt(proj[i].substring(1,2));  
        py[i] = Integer.parseInt(proj[i].substring(3,4)); 
        // System.out.println("px " + px[i] + ", py " + py[i]);
    }
    // System.out.println("proj length " + proj.length);
    float alpha = 0.3F;
    g.setComposite(makeComposite(alpha));
    
        for (int j = 0; j < Mx.rows; ++j) {
            if (Mx.columns == 1) {
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(Mx.element[j][px[0]]-(pointsize/2), My.element[j][py[0]]-(pointsize/2), pointsize, pointsize); g.fill(circ);
            }            
            else if (Mx.columns == 2) {
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(Mx.element[j][px[0]]-(pointsize/2), My.element[j][px[0]]-(pointsize/2), pointsize, pointsize); g.fill(circ);
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(Mx.element[j][px[1]]-(pointsize/2), My.element[j][py[1]]-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            }            
            else if (Mx.columns == 3) {
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(Mx.element[j][px[0]]-(pointsize/2), My.element[j][py[0]]-(pointsize/2), pointsize, pointsize); g.fill(circ);
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(Mx.element[j][px[1]]-(pointsize/2), My.element[j][py[1]]-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(Mx.element[j][px[2]]-(pointsize/2), My.element[j][py[2]]-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            }
            else if (Mx.columns == 4) {
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(Mx.element[j][px[0]]-(pointsize/2), My.element[j][py[0]]-(pointsize/2), pointsize, pointsize); g.fill(circ);
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(Mx.element[j][px[1]]-(pointsize/2), My.element[j][py[1]]-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(Mx.element[j][px[2]]-(pointsize/2), My.element[j][py[2]]-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            g.setColor(Color.MAGENTA);
            Ellipse2D.Double circ4 = new Ellipse2D.Double(Mx.element[j][px[3]]-(pointsize/2), My.element[j][py[3]]-(pointsize/2), pointsize, pointsize); g.fill(circ4);
            }            
            else if (Mx.columns == 5) {
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(Mx.element[j][px[0]]-(pointsize/2), My.element[j][py[0]]-(pointsize/2), pointsize, pointsize); g.fill(circ);
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(Mx.element[j][px[1]]-(pointsize/2), My.element[j][py[1]]-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(Mx.element[j][px[2]]-(pointsize/2), My.element[j][py[2]]-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            g.setColor(Color.MAGENTA);
            Ellipse2D.Double circ4 = new Ellipse2D.Double(Mx.element[j][px[3]]-(pointsize/2), My.element[j][py[3]]-(pointsize/2), pointsize, pointsize); g.fill(circ4);
            g.setColor(turq);
            Ellipse2D.Double circ5 = new Ellipse2D.Double(Mx.element[j][px[4]]-(pointsize/2), My.element[j][py[4]]-(pointsize/2), pointsize, pointsize); g.fill(circ5);
            }
            else if (Mx.columns == 6) {
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(Mx.element[j][px[0]]-(pointsize/2), My.element[j][py[0]]-(pointsize/2), pointsize, pointsize); g.fill(circ);
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(Mx.element[j][px[1]]-(pointsize/2), My.element[j][py[1]]-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(Mx.element[j][px[2]]-(pointsize/2), My.element[j][py[2]]-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            g.setColor(Color.MAGENTA);
            Ellipse2D.Double circ4 = new Ellipse2D.Double(Mx.element[j][px[3]]-(pointsize/2), My.element[j][py[3]]-(pointsize/2), pointsize, pointsize); g.fill(circ4);
            g.setColor(turq);
            Ellipse2D.Double circ5 = new Ellipse2D.Double(Mx.element[j][px[4]]-(pointsize/2), My.element[j][py[4]]-(pointsize/2), pointsize, pointsize); g.fill(circ5);
            g.setColor(Color.yellow);
            Ellipse2D.Double circ6 = new Ellipse2D.Double(Mx.element[j][px[5]]-(pointsize/2), My.element[j][py[5]]-(pointsize/2), pointsize, pointsize); g.fill(circ6);
            }
            else if (Mx.columns == 7) {
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(Mx.element[j][px[0]]-(pointsize/2), My.element[j][py[0]]-(pointsize/2), pointsize, pointsize); g.fill(circ);
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(Mx.element[j][px[1]]-(pointsize/2), My.element[j][py[1]]-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(Mx.element[j][px[2]]-(pointsize/2), My.element[j][py[2]]-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            g.setColor(Color.MAGENTA);
            Ellipse2D.Double circ4 = new Ellipse2D.Double(Mx.element[j][px[3]]-(pointsize/2), My.element[j][py[3]]-(pointsize/2), pointsize, pointsize); g.fill(circ4);
            g.setColor(turq);
            Ellipse2D.Double circ5 = new Ellipse2D.Double(Mx.element[j][px[4]]-(pointsize/2), My.element[j][py[4]]-(pointsize/2), pointsize, pointsize); g.fill(circ5);
            g.setColor(Color.yellow);
            Ellipse2D.Double circ6 = new Ellipse2D.Double(Mx.element[j][px[5]]-(pointsize/2), My.element[j][py[5]]-(pointsize/2), pointsize, pointsize); g.fill(circ6);
            g.setColor(Color.GREEN);
            Ellipse2D.Double circ7 = new Ellipse2D.Double(Mx.element[j][px[6]]-(pointsize/2), My.element[j][py[6]]-(pointsize/2), pointsize, pointsize); g.fill(circ7);
            }
            else if (Mx.columns == 8) {
            g.setColor(Color.red);
            Ellipse2D.Double circ = new Ellipse2D.Double(Mx.element[j][px[0]]-(pointsize/2), My.element[j][py[0]]-(pointsize/2), pointsize, pointsize); g.fill(circ);
            g.setColor(Color.blue);
            Ellipse2D.Double circ2 = new Ellipse2D.Double(Mx.element[j][px[1]]-(pointsize/2), My.element[j][py[1]]-(pointsize/2), pointsize, pointsize); g.fill(circ2);
            g.setColor(Color.orange);
            Ellipse2D.Double circ3 = new Ellipse2D.Double(Mx.element[j][px[2]]-(pointsize/2), My.element[j][py[2]]-(pointsize/2), pointsize, pointsize); g.fill(circ3);
            g.setColor(Color.MAGENTA);
            Ellipse2D.Double circ4 = new Ellipse2D.Double(Mx.element[j][px[3]]-(pointsize/2), My.element[j][py[3]]-(pointsize/2), pointsize, pointsize); g.fill(circ4);
            g.setColor(turq);
            Ellipse2D.Double circ5 = new Ellipse2D.Double(Mx.element[j][px[4]]-(pointsize/2), My.element[j][py[4]]-(pointsize/2), pointsize, pointsize); g.fill(circ5);
            g.setColor(Color.yellow);
            Ellipse2D.Double circ6 = new Ellipse2D.Double(Mx.element[j][px[5]]-(pointsize/2), My.element[j][py[5]]-(pointsize/2), pointsize, pointsize); g.fill(circ6);
            g.setColor(Color.GREEN);
            Ellipse2D.Double circ7 = new Ellipse2D.Double(Mx.element[j][px[6]]-(pointsize/2), My.element[j][py[6]]-(pointsize/2), pointsize, pointsize); g.fill(circ7);
            g.setColor(Color.DARK_GRAY);
            Ellipse2D.Double circ8 = new Ellipse2D.Double(Mx.element[j][px[7]]-(pointsize/2), My.element[j][py[7]]-(pointsize/2), pointsize, pointsize); g.fill(circ8);
            }            
        } 
    }

    public void Dot(Graphics2D g3, BigDecimal x1, BigDecimal y1, int pointsize, float aleph){
        double plotdoublex = x1.doubleValue();
        double plotdoubley = y1.doubleValue();
        float alpha = aleph;
        Ellipse2D.Double circle = new Ellipse2D.Double(plotdoublex-(pointsize/2), plotdoubley-(pointsize/2), pointsize, pointsize);
        g3.setComposite(makeComposite(alpha));
        g3.fill(circle);
    }
    
    public void Line(Graphics2D g, Complex p, Complex q){
       g.setColor(Color.black);
       g.draw(new Line2D.Double(p.x,p.y,q.x,q.y));
    }
     
    public void ExtLine(Graphics2D g, Complex p, Complex q){
       double slope, y3, y4;
       // solve point slope form for x3 = 1000 and x4 = -1000
       slope = (q.y - p.y)/(q.x - p.x);
       y3 = (slope * (1000 - p.x)) + p.y;
       y4 = (slope * (-1000 - p.x)) + p.y;
       // System.out.println(p.x + ", p.y  " + p.y + ", q.x  "+ q.x +", q.y  "+ q.y);
       g.setColor(Color.LIGHT_GRAY);
       g.draw(new Line2D.Double(p.x, p.y, 1000, y3));
       g.draw(new Line2D.Double(p.x, p.y, -1000, y4));
       g.setColor(Color.black);
       Line2D line = new Line2D.Double(p.x,p.y,q.x,q.y);
       g.draw(line);
    }    
    
    private AlphaComposite makeComposite(float alpha) {
        int type = AlphaComposite.SRC_OVER;
        return(AlphaComposite.getInstance(type, alpha));
    } 
   
    public Point2D.Double getIntersectionPoint(Line2D.Double line1, Line2D.Double line2) {
    if (! line1.intersectsLine(line2) ) return null;
      double px = line1.getX1(),
            py = line1.getY1(),
            rx = line1.getX2()-px,
            ry = line1.getY2()-py;
      double qx = line2.getX1(),
            qy = line2.getY1(),
            sx = line2.getX2()-qx,
            sy = line2.getY2()-qy;
      double det = sx*ry - sy*rx;
      if (det == 0) {
        return null;
      } 
      else {
        double z = (sx*(qy-py)+sy*(px-qx))/det;
        if (z==0 ||  z==1) return null;  // intersection at end point!
        return new Point2D.Double(
          (double)(px+z*rx), (double)(py+z*ry));
      }
    }    
    

    public void Bg(Graphics2D g, ListenSquare L, String s){
          float alpha = 0.90F;
          g.setComposite(makeComposite(alpha));
          g.setColor(Color.black);
          L.render(g, Color.LIGHT_GRAY);
          
          g.setColor(Color.white);
          g.setFont(new Font("Helvetica", Font.BOLD, 17));  
          if (s == "Plus") {
            g.drawString("+", 33, 491);
            }          
          else if (s == "SizePlus") {
            g.drawString("+", 33, 467);
            }
          else if (s == "Minus") {
            g.drawString("-", 12, 491);
            g.setFont(new Font("Helvetica", Font.PLAIN, 10));  
            g.setColor(Color.black);
            g.drawString("ZOOM", 55, 491);   }       
          else if (s == "SizeMinus") {
            g.drawString("-", 12, 467);
            g.setFont(new Font("Helvetica", Font.PLAIN, 10));  
            g.setColor(Color.black);
            g.drawString("POINTSIZE", 55, 467);
          }          
          else if (s == "vPlus") {
            g.drawString("+", 163, 21);
            }          
          else if (s == "nPlus") {
            g.drawString("+", 197, 222);
            }
          else if (s == "nMinus") {
            g.drawString("-", 177, 222);
            g.setFont(new Font("Helvetica", Font.PLAIN, 10));  
            g.setColor(Color.black);
            g.drawString("N", 158, 223);   }       
          else if (s == "vMinus") {
            g.drawString("-", 143, 21);
            g.setFont(new Font("Helvetica", Font.PLAIN, 10));  
            g.setColor(Color.black);
            g.drawString("V", 124, 21);
          }
      }
    
    public void Twisted(Graphics2D g3, int vertices, int n){
        float alpha = 0.1F;
        Complex[] d = new Complex[vertices];
        Complex interim = new Complex(1,1);
        Gon polygon = new Gon(n, vertices, interim); // will not be used, except for matrix
        MMatrix M = polygon.getM();
        double a = M.element[0][0];
        double b = M.element[1][1];
        // System.out.println("a:  " + a + ", b: " + b);
        g3.setComposite(makeComposite(alpha));
        
        if (n == 1) { for (int i = 0; i < vertices; ++i) {
            double vx = i*a;
            double vy = i*b;
            d[i] = new Complex (vx, vy); } }
        else if (n == 2) { for (int i = 0; i < vertices; ++i) {
            double vx = a*i;
            double vy = b*i;
            d[i] = new Complex (vx, vy);
            double vx2 = vx*a;
            double vy2 = vy*b;
            d[i+1] = new Complex (vx2, vy2);
            i += 1; } }
        else if (n == 3) { for (int i = 0; i < (vertices-2); ++i) {
            double vx1 = a*i;
            double vy1 = b*i;
            d[i] = new Complex (vx1, vy1);
            double vx2 = vx1*a;
            double vy2 = vy1*b;
            d[i+1] = new Complex (vx2, vy2);
            double vx3 = vx2*a;
            double vy3 = vy2*b;
            d[i+2] = new Complex (vx3, vy3); 
            i += 2; } }
        for (int l = 0; l < d.length; ++l) {
            System.out.println(l);
            Ellipse2D.Double circle = new Ellipse2D.Double(d[l].x, d[l].y, 1, 1);
            g3.setColor(Color.blue);
            alpha += 0.05F;
            g3.setComposite(makeComposite(alpha));
            g3.fill(circle);
        
        }         

    }
    
    


}





