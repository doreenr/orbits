package automaton;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Doreen
 */

import java.applet.Applet;
import java.awt.event.*;
import java.awt.*;

public class Maus {
    int mode;
    Point X;

    public  Maus() {}

    public static Maus process(MouseEvent e) {
	Point X=new Point();
        int mode=0;
        if(e.getButton()==MouseEvent.BUTTON1) mode=1;
        if(e.getButton()==MouseEvent.BUTTON2) mode=2;
        if(e.getButton()==MouseEvent.BUTTON3) mode=3;
        e.consume();
        X.x=e.getX();
        X.y=e.getY();
	Maus J=new Maus();
	J.X=X;
	J.mode=mode;
	return(J);
    }


    public static Maus process(MouseEvent e,int q) {
	Point X=new Point();
        int mode=0;
	if(q>0) mode=q;
	if(q==0) {
          if(e.getButton()==MouseEvent.BUTTON1) mode=1;
          if(e.getButton()==MouseEvent.BUTTON2) mode=2;
          if(e.getButton()==MouseEvent.BUTTON3) mode=3;
	}
        e.consume();
        X.x=e.getX();
        X.y=e.getY();
	Maus J=new Maus();
	J.X=X;
	J.mode=mode;
	return(J);
    }
    
}

    

