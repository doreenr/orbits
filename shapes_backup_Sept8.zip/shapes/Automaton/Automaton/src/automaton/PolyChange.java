/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package automaton;

/**
 *
 * @author Doreen
 */

import java.util.*;
import java.applet.Applet;
import java.awt.event.*;
import java.awt.geom.*;
import java.applet.*;
import java.awt.Graphics2D;
import java.math.*;

public class PolyChange {
        
    public static PolygonWrapper addPoint(PolygonWrapper P) {
         PolygonWrapper L=new PolygonWrapper(P);
         Complex [] z = new Complex[100];
         
         for (int i=0; i<100; i++){
             z[i] = new Complex(400*Math.random(),330*Math.random()+70);
         }
         
         for(int j=0;j<100;j++){
           if(containPts(P,z[j])==false && onSide(z[j],P)==false){               
         L.z[P.count]=z[j];
         L.count++;
         break;  
               }
             }      
         L = convexhull(L);
         
         return(L);
     }
    
    
     public static PolygonWrapper line() {
         PolygonWrapper L=new PolygonWrapper();
         L.z[0]=new Complex(400*Math.random(),400*Math.random());
         L.z[1]=new Complex(400*Math.random(),400*Math.random());
         L.count=2;
         return(L);
     }
     
     
     public static PolygonWrapper deletePoint(PolygonWrapper P) {
         PolygonWrapper L=new PolygonWrapper(P);
       --L.count;
         return(L);
     }
     
    
    public static PolygonWrapper changePolygonf(PolygonWrapper P, Complex SOURCE) {
     PolygonWrapper L = new PolygonWrapper(P);
     int i=P.nearest(SOURCE);
     L.z[i]=new Complex(SOURCE);
     return(L);
}
    
    
    public static PolygonWrapper interPoly(PolygonWrapper P1, PolygonWrapper P2){
        if(P1==null) return(null);
        if(P2==null) return(null);
        PolygonWrapper Q=new PolygonWrapper();
        Q.count=0;
        for(int i=0;i<P1.count;i++){
            for(int j=0;j<P2.count;j++){
                int i1=i;
                int i2=(i+1)% P1.count;
                int j1=j;
                int j2=(j+1)% P2.count;
                Complex q=interPts(P1.z[i1],P1.z[i2],P2.z[j1],P2.z[j2]);
                if(q!=null){
                    Q.z[Q.count]=new Complex(q);
                    Q.count++;
                }
            }
        }
        
        for(int i=0;i<P1.count;i++){
            if(containPts(P2,P1.z[i])==true){
                Q.z[Q.count]=new Complex(P1.z[i]);
                Q.count++;
            }
        }
        
        for(int k=0;k<P2.count;k++){
            if(containPts(P1,P2.z[k])==true){
                Q.z[Q.count]=new Complex(P2.z[k]);
                Q.count++;
            }
        }
        Q = convexhull(Q);
        
        return(Q);
    }
    
   public static List<Complex> Dots(PolygonWrapper P1, PolygonWrapper P2,Graphics2D g2){
        if(P1==null) return(null);
        if(P2==null) return(null);
        List<Complex> vdots=new ArrayList<Complex>();
        
        for(int i=0;i<P1.count;i++){
            for(int j=0;j<P2.count;j++){
                int i1=i;
                int i2=(i+1)% P1.count;
                int j1=j;
                int j2=(j+1)% P2.count;
                Complex q=interPts(P1.z[i1],P1.z[i2],P2.z[j1],P2.z[j2]);
                if(q!=null) vdots.add(q);
               
            }
        }
        
        for(int i=0;i<P1.count;i++){
            if(containPts(P2,P1.z[i])==true){
                vdots.add(P1.z[i]);
            }
        } 
        for(int j=0;j<P2.count;j++){
            if(containPts(P1,P2.z[j])==true){
                vdots.add(P2.z[j]);
            }
        }
        
        Graphics2D g=(Graphics2D) g2;
        if(vdots.size()>0) {
            for(int i=0;i<vdots.size();i++){
                Complex z=vdots.get(i);
                // DrawMe.drawDots(g,z);
           }
        }     
        return(vdots);
    }
    

        public static Complex interPts(Complex z0, Complex z1, Complex w0, Complex w1){
     Complex w=interPts1(z0,z1,w0,w1);
     
     double[] m=new double[12];
     m[0]= Math.min(z0.x,z1.x);
     m[1]=Math.min(w0.x, w1.x);
     m[2]=Math.max(m[0],m[1]);
     m[3]=Math.max(z0.x,z1.x);
     m[4]=Math.max(w0.x, w1.x);
     m[5]=Math.min(m[3],m[4]);
     m[6]= Math.min(z0.y,z1.y);
     m[7]=Math.min(w0.y, w1.y);
     m[8]=Math.max(m[6],m[7]);
     m[9]=Math.max(z0.y,z1.y);
     m[10]=Math.max(w0.y, w1.y);
     m[11]=Math.min(m[9],m[10]);
     
     if(w==null) return(null);
     if(w!=null){
         if((w.x < m[2])||(w.x > m[5])) return(null);
         if((w.x==m[2])||(w.x==m[5])) {
            if((w.y < m[8])||(w.y > m[11])) return(null);
       }     
     }
     return(w);
    }
    
    
    public static Complex interPts1(Complex z0, Complex z1, Complex w0, Complex w1){
    
        double x0=z0.x;
        double y0=z0.y;
        double x1=z1.x;
        double y1=z1.y;
        double x2=w0.x;
        double y2=w0.y;
        double x3=w1.x;
        double y3=w1.y;
        Complex w=null;
        
        double d=(x0 - x1) * (y2 - y3) - (y0 - y1) * (x2 - x3);
        
         if(d==0) w=null;
         
         if (d != 0) {
         double xi = ((x2 - x3) * (x0 * y1 - y0 * x1) - (x0 - x1) * (x2 * y3 - y2 * x3)) / d;
         double yi = ((y2 - y3) * (x0 * y1 - y0 * x1) - (y0 - y1) * (x2 * y3 - y2 * x3)) / d;
         w = new Complex(xi,yi); 
         }
         
         return(w);
      }
    
    
    public static double side(Complex z0, Complex z1, Complex w){
       Complex Z0=Complex.minus(z0,w);
       Complex Z1=Complex.minus(z1,w);
       Complex A=Complex.times(Z0,Z1.conjugate());
       return(A.y);
     }
     
    public static boolean onSide(Complex z, PolygonWrapper P){
        for(int i=0; i<P.count; i++){
            int i1 = i;
            int i2 = (i+1)%P.count;
            if(side(P.z[i1],P.z[i2],z)==0) return(true);      
        }
        return(false);
    }
    
    public static boolean containPts(PolygonWrapper P, Complex z){
          for(int i=0; i<P.count;i++) {
        int i1=i; 
        int i2=(i+1)% P.count;
        int i3=(i+2)% P.count;
        Complex w1=P.z[i1];
        Complex w2=P.z[i2];
        Complex w3=P.z[i3];
        double t1=side(w1,w2,w3)*side(w1,w2,z);       
        if(t1<0) return(false);
        if(t1==0) {
            if(isBetween(w1,w2,z)==false) return(false);
        }
        
        }
    return(true);
    }
    
    
    public static boolean isBetween(Complex z1,Complex z2,Complex w) {
        double d1=Complex.dist(w,z1);
        double d2=Complex.dist(w,z2);
        double d3=Complex.dist(z1,z2);
        double test=d1+d2-d3;
        if(test<.000000001) return(true);
        return(false);
    }
  
  //Find the bottom vertex with smaller x-coordinate
    public static int bottom(PolygonWrapper P){
        double testx, testy, lowestx, lowesty;
        int B = -1;
        lowestx = 10000.0;
        lowesty = 0;
           
        for(int i=0;i<P.count;i++){
            testx = P.z[i].x;
            testy = P.z[i].y;
          if(testy > lowesty || (testy == lowesty && testx < lowestx)){
              B = i;
              lowesty = testy;
              lowestx = testx;
          }  
        }
       
       return(B); 
    }
    
    //Sort the points by angle around the bottom vertex
    public static int[] order(PolygonWrapper P){
        double[] sin;
        double[] angle;
        double[] ordangle;
        int B = bottom(P);
        int[] n;
        Map<Double, Integer> map = new TreeMap<Double, Integer>();
        
        n = new int[P.count];
        n[0]=bottom(P);
        
        sin = new double[P.count];
     
        for(int i=0; i<P.count; i++){
            sin[i] = (P.z[B].y-P.z[i].y) / Complex.dist(P.z[i], P.z[B]); 
        }
       
        angle = new double[P.count];
      
        for(int i=0; i<P.count; i++){
           if(P.z[i].y == P.z[B].y && P.z[i].x >= P.z[B].x) angle[i] = 0; 
           
           if(P.z[i].y == P.z[B].y && P.z[i].x < P.z[B].x) angle[i] = Math.PI; 
            
           if(P.z[i].y != P.z[B].y && P.z[i].x >= P.z[B].x) angle[i] = Math.asin(sin[i]);
            
           if(P.z[i].y != P.z[B].y && P.z[i].x < P.z[B].x) angle[i] = Math.PI - Math.asin(sin[i]);
           
           map.put(angle[i], i);   
        
        }
  
        ordangle = angle;
         for(int k=0; k<P.count; k++){
             for(int j=k+1; j < P.count; j++){
                 if(ordangle[k] > ordangle[j]){
                     double temp = ordangle[k];
                     ordangle[k] = ordangle[j];
                     ordangle[j] = temp;
                }
                 
                 if(ordangle[k]==ordangle[j] && Complex.dist(P.z[k], P.z[B]) > Complex.dist(P.z[j], P.z[B])){
                     double temp = ordangle[k];
                     ordangle[k] = ordangle[j];
                     ordangle[j] = temp;
                 }
                 
             }
            
             n[k] = map.get(ordangle[k]);
          }
      
       return(n);
    }
    
  
    public static double dist(Complex z1, Complex z2){
        double d;
        
        d = Math.sqrt((z2.x-z1.x)*(z2.x-z1.x)+(z1.y-z2.y)*(z1.y-z2.y));
        
        return(d);
    }
    
   public static PolygonWrapper eraserep(PolygonWrapper P){
       PolygonWrapper Q = new PolygonWrapper();
       int count = 0;
       Q.z[0] = new Complex(P.z[0]);
       for(int i=0;i<P.count;i++){
           Complex w = new Complex(P.z[i]);
           boolean redundant = false;
           
           for(int j=0;j<count;j++){
               if(Complex.dist(w,Q.z[j])<0.000000001) redundant = true;
           } 
           
           if(redundant==false){
               Q.z[count] = new Complex(w);
               count++;
           }
       }
       Q.count = count;
       return(Q);
   } 
   
    
  //Build convex hull for proper points
    public static PolygonWrapper convexhull(PolygonWrapper PP){
 
        int count = 1; 
        double test;
        
        if(PP == null) return(null);
        if(PP.count == 0) return(null);
        
        PolygonWrapper P = eraserep(PP);
        int[] n = order(P);
        
        if(P.count == 1) return(null);
        if(P.count == 2) return(P);
        if(P.count == 3) return(P);
               
        PolygonWrapper Q = new PolygonWrapper();
       
        Q.z[0] = P.z[n[0]];
        
        System.out.println("Start left and right");
        for(int i=1;i<P.count;i++){
          double x1 = P.z[n[i]].x;
          double y1 = P.z[n[i]].y;
          double x2 = P.z[n[i-1]].x;
          double y2 = P.z[n[i-1]].y;
          double x3 = P.z[n[(i+1)% P.count]].x;
          double y3 = P.z[n[(i+1)% P.count]].y;
 
          test = (x2-x1)*(y1-y3)-(y1-y2)*(x3-x1);
          
          System.out.println(test +": " +P.z[n[i]].x +","+ P.z[n[i]].y + " ,pos:" + n[i]);
          
         if(y1!=y3 && test < 0){ 
            Q.z[count] = P.z[n[i]];  
            count++;
        }    
         if(y1==y3){
             Q.z[count] = P.z[n[i]];
             count++;
         }
         
        }  
       Q.count =count; 
       
        return(Q);
             
    }
    
}

       
       
    




