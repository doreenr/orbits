/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package automaton;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;

/**
 *
 * @author Doreen
 */
public class leftCanvas extends Canvas {
	// Every left canvas has a random colored oval in it
	// every time it is repainted, it is generated and painted
	int h, w; // the height and width of this canvas
        
        /*
	public void paint0(Graphics win) {
		int ovalDia;
		int x, y;
		// set the height and width of this canvas
		// this depends on where it is added, so we'll use
		// getSize to get its dimensions
		h = getSize().height;
		w = getSize().width;
		win.drawRect(0,0, w, h);	// Draw border
		// draw a random colored oval
		ovalDia = (int) (Math.random()*(w/4));
		x = (int) (Math.random()*w);
		y = (int) (Math.random()*h);
		win.fillOval(x, y, ovalDia, ovalDia);   */
        public void paint(Graphics2D g){
                int x, y;
		h = getSize().height;
		w = getSize().width;
                g.drawRect(0,0, w/2, h/2);
		x = (int) (Math.random()*w);
		y = (int) (Math.random()*h);
                Ellipse2D.Double circle = new Ellipse2D.Double(x,y,5,5);
                g.setColor(Color.black);
                g.fill(circle);
        }
		
} // leftCanvas
