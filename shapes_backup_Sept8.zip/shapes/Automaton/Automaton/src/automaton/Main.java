/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package automaton;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import javax.swing.JPanel;


/**
 *
 * @author Doreen
 */

public class Main extends Applet {
    Leinwand_Pi P;
    Button goButton;
    Leinwand_Pi L;
    leftCanvas R;

    public static void main(String[] args) {  
        Main a = new Main();        
        Frame2 F = new Frame2("Pentagram Automaton", a);
	a.setBackground(new Color(255,255,255));
                  a.init();
	F.add(a);
	// F.pack();
        F.setSize(1400, 800);
	F.addWindowListener(new WinList(F));
	F.setVisible(true);
    }


    public void init() {   
        /*
	P= new Leinwand_Pi();
	add(P);
	P.setSize(1400,800);*/
        
	setLayout(new BorderLayout());
	goButton = new Button("Do it again!");
	JPanel Panel2 = new JPanel();
	Panel2.add(goButton);
	add("South", Panel2);
		// goButton.addActionListener(this);
		
		// add the two canvases
	JPanel Panel1 = new JPanel();
	Panel1.setLayout(new GridLayout(1,2));
	L = new Leinwand_Pi();
        L.setSize(400,800);
	R = new leftCanvas();
        R.setSize(400,800);
	Panel1.add(L);
	Panel1.add(R);
	add("Center", Panel1);
        
    } 

    public static class Frame2 extends Frame implements ComponentListener {
        Main a;

        public Frame2(String W, Main a) {
            super(W);
            this.a = a;
            addComponentListener(this);
        }


        public void componentHidden(ComponentEvent e) {
        }
        
        public void componentMoved(ComponentEvent e) {
        }
        
        public void componentResized(ComponentEvent e) {
	    // a.P.setSize(getWidth(),getHeight());
	}

        public void componentShown(ComponentEvent e) {
        }
        
    }

    
}
