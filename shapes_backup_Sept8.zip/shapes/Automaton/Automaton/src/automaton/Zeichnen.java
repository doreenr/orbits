/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package automaton;

/**
 *
 * @author Doreen
 */


import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.geom.*;
import java.math.*;
import java.util.*;
import javax.swing.*;



public class Zeichnen extends Canvas {
    
      public void Bg(Graphics2D g, QuadratTrack Q1, QuadratTrack Q2, QuadratTrack Q3){
          g.setColor(Color.white);
          g.fillRect(0,0,getWidth(),getHeight());
          Q1.render(g, Color.DARK_GRAY);
          Q2.render(g, Color.DARK_GRAY);
          Q3.render(g, Color.DARK_GRAY);
          g.setColor(Color.white);
          g.drawString("Plot Initial Polygon", 15, 23);
          g.drawString("Increase Dimension", 15, 51);
          g.drawString("Apply Automaton Map", 15, 81);
      }
    
     private AlphaComposite makeComposite(float alpha) {
        int type = AlphaComposite.SRC_OVER;
        return(AlphaComposite.getInstance(type, alpha));
     }
      
     public void Dot(Graphics2D g, Complex z){
        double x1=z.x;
        double y1=z.y;
        Ellipse2D.Double circle = new Ellipse2D.Double(x1,y1,5,5);
        g.setColor(Color.black);
        
        /*
        AffineTransform at1 = new AffineTransform();
        at1.translate(150,200);
        g.transform(at1);
        g.fill(circle);*/
       
     }
    
     public void Orbit(Graphics2D g, float alpha){

        // Construct Matrix        
        Matrix Mx = new Matrix(5,200);
        Mx.element[1][0] = 2;
        Mx.element[1][1] = 3;
        Mx.element[1][2] = 1;
        Mx.element[1][3] = 9;
        Mx.element[1][4] = 8;
        
        Matrix My = new Matrix(5,200);
        My.element[1][0] = 3;
        My.element[1][1] = 4;
        My.element[1][2] = 2;
        My.element[1][3] = 7;
        My.element[1][4] = 3;
              
        double xtemp[] = Mx.element[1];
        double ytemp[] = My.element[1]; 
        double dx[] = Mx.element[1];
        double dy[] = My.element[1]; 
        
        for (int k = 0; k < Mx.columns; k++){
            for (int i = 0; i < Mx.rows; i++){
                int j1 = Reduce.main(i-1);
                // double max1 = Math.max(0, xtemp[(i-1) % Mx.rows]+ytemp[(i-1) % Mx.rows]);
                // CHECK BERECHNUNG
                double max2 = Math.max(0, xtemp[(i+1) % Mx.rows]+ytemp[(i+1) % Mx.rows]);
                double max3 = Math.max(0, xtemp[j1-1]+ytemp[j1-1]);
                dx[i] = dx[i] + max3 - max2;

                double max4 = Math.max(0, xtemp[(i+2) % Mx.rows] + ytemp[(i+2) % Mx.rows]);
                double max5 = Math.max(0, xtemp[i] + ytemp[i]);
                dy[i] = dy[(i+1) % Mx.rows] + max4 - max5;
                
                Ellipse2D.Double circle = new Ellipse2D.Double(dx[i],dy[i],5,5);
 
                g.setColor(Color.black);
                g.fill(circle);
                g.setComposite(makeComposite(alpha));
                
                }
        }
               
     }
     
      public void Line(Graphics2D g, Complex p, Complex q){
       g.setColor(Color.black);
       g.draw(new Line2D.Double(p.x,p.y,q.x,q.y));
    }
      
    public void drawPolygon1(Graphics2D g, PolygonWrapper P1) {
       GeneralPath gp = P1.toGeneralPath();
       g.setColor(Color.orange);
       g.fill(gp);
       g.setColor(Color.orange);
       g.draw(gp);
    }
    
    public void drawPolygon2(Graphics2D g, PolygonWrapper P2) {
       GeneralPath gp=P2.toGeneralPath();
       g.setColor(Color.gray);
       //g.fill(gp);
       g.setColor(Color.gray);
       g.draw(gp);
    }
    
    public static void addVertex(Graphics2D g, Complex[] w){
      if(w.length > 3){ 
        for(int i=0; i < w.length; i++){
        Ellipse2D.Double circle=new Ellipse2D.Double(w[i].x, w[i].y, 5, 5);
        g.setColor(Color.green);
        g.fill(circle);    
        }
       }
    }


}
