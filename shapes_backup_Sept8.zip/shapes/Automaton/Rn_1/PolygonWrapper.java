package convex.polygon;

import java.applet.Applet;
import java.awt.event.*;
import java.awt.*;
import java.awt.geom.*;

/**This is wrapper class for a list of points in the
   plane.  The main routines in this class are 
   1. taking the convex hull of a finite set of points.
   2. intersecting two convex polygons.
**/


public class PolygonWrapper {
    Complex[] z=new Complex[1000];
    int count;



    /**Constructors**/
    public PolygonWrapper() {}
    
    
    
    public PolygonWrapper(PolygonWrapper X) {
        this.count=X.count;
        for(int i=0;i<count;++i) this.z[i]=new Complex(X.z[i]);
    }
    
    
    
    

    public PolygonWrapper(int cc,Complex[] zz) {
	this.count=cc;
	for(int i=0;i<cc;++i) {
             z[i]=new Complex(zz[i]);
	}
    }

    /**For drawing the polygon**/

    public GeneralPath toGeneralPath() {
	GeneralPath gp=new GeneralPath();
	gp.moveTo((float)(z[0].x),(float)(z[0].y));
	for(int i=0;i<count;++i) {
	    gp.lineTo((float)(z[i].x),(float)(z[i].y));
	}
	gp.closePath();
	return(gp);
    }

  /*converts a polygonal generalpath into a polygon*/
  public static PolygonWrapper fromGeneralPath(GeneralPath X) {
	PolygonWrapper Y=new PolygonWrapper();
	AffineTransform A=AffineTransform.getTranslateInstance(0,0);
	PathIterator P=X.getPathIterator(A);
	double[] coords=new double[6];
	int count=0;
	Complex HISTORY=new Complex(-9999,-9999);
	Complex CURRENT=new Complex();
	while(P.isDone()==false) {
	    P.currentSegment(coords);
	    CURRENT=new Complex(coords[0],coords[1]);
	    if(Complex.dist(CURRENT,HISTORY)>.00000001) {
	        Y.z[count]=new Complex(CURRENT);
		++count;
		HISTORY=new Complex(CURRENT);
	    }
	    P.next();
	}  
	Y.count=count;
	return(Y);
    }

    public boolean contains(Complex z) {
	GeneralPath gp=this.toGeneralPath();
	return(gp.contains(z.x,z.y));
    }

public int nearest(Complex w) {
  int index=0;
  double min=10000000;
  for(int i=0;i<count;++i) {
    double dist=Complex.dist(this.z[i],w);
    if(dist<min) {
      index=i;
      min=dist;
    }
  }
return(index);
}

    /**printout**/

    public void print() {
	System.out.println("count "+count);
	for(int i=0;i<count;++i) z[i].print();
    }

}
