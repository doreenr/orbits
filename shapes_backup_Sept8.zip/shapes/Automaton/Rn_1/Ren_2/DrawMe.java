package doreen;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.geom.*;
import java.math.*;


public class DrawMe extends Canvas {
    


      public void Bg(Graphics2D g, ListenSquare L, ListenSquare Line){
          g.setColor(Color.black);
          g.fillRect(0,0,getWidth(),getHeight());
          
          L.render(g, Color.red);       
          Line.render(g, Color.orange);
          
          g.setColor(Color.white);
          g.drawString("Line", 65, 15);
          g.drawString("Dots", 5, 15);
      }
      
      
     public void Dot(Graphics2D g, Complex z){
        double x1=z.x;
        double y1=z.y;
        Ellipse2D.Double circle=new Ellipse2D.Double(x1,y1,5,5);
        g.setColor(Color.blue);
        g.fill(circle);
     } 
     
      public void Line(Graphics2D g, Complex p, Complex q){
       g.setColor(Color.white);
       g.draw(new Line2D.Double(p.x,p.y,q.x,q.y));
    }
      
    public void drawPolygon1(Graphics2D g, PolygonWrapper P1) {
       GeneralPath gp=P1.toGeneralPath();
       g.setColor(Color.orange);
       g.fill(gp);
       g.setColor(Color.orange);
       g.draw(gp);
    }

  
    public void drawPolygon2(Graphics2D g, PolygonWrapper P2) {
       GeneralPath gp=P2.toGeneralPath();
       g.setColor(Color.gray);
       //g.fill(gp);
       g.setColor(Color.gray);
       g.draw(gp);
    }
   
    public static void drawDots(Graphics2D g, Complex z){
        double x1=z.x;
        double y1=z.y;
        Ellipse2D.Double circle=new Ellipse2D.Double(x1,y1,5,5);
        g.setColor(Color.red);
        g.fill(circle);
     }
    
    public static void addVertex(Graphics2D g, Complex[] w){
      if(w.length > 3){ 
        for(int i=0; i < w.length; i++){
        Ellipse2D.Double circle=new Ellipse2D.Double(w[i].x, w[i].y, 5, 5);
        g.setColor(Color.green);
        g.fill(circle);    
        }
       }
      
    }
}
