package doreen;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.geom.*;
import java.math.*;
import java.util.*;
import java.util.Random;

public class ControlCanvas extends Canvas implements MouseListener, MouseMotionListener, KeyListener {

    ListenSquare L, Control, Line;
    DrawMe draw;
    Complex[] z;
    boolean drawline;
    Graphics2D g3;

    public ControlCanvas() {
        addMouseListener(this);
        addMouseMotionListener(this);
        addKeyListener(this);
        draw = new DrawMe();
        L = new ListenSquare(0, 0, 60, 25);
        Line = new ListenSquare(60, 0, 60, 25);
        z = new Complex[10];
        
        for(int i=0; i<z.length;i++){
            z[i] = new Complex(400*Math.random(),400*Math.random());
//            System.out.println(z[i].x+","+z[i].y+","+i);
        }
    }

    public void paint(Graphics g2) {
        Graphics2D g = (Graphics2D) g2;
        g3 = g;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        draw.Bg(g, L,Line);
        for(int i=0; i<z.length;i++){
        draw.Dot(g, z[i]);
        }
        

          for(int i=0; i<z.length;i++){
            draw.Line(g, z[i], z[(i+1) % z.length]);
   
        }
    }

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseMoved(MouseEvent e) {
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {
        MouseData J = MouseData.process(e);

        repaint();

    }

    public void mouseClicked(MouseEvent e) {
        MouseData J = MouseData.process(e);

        boolean control = Control.inside(J.X);
        boolean dots = L.inside(J.X);
  
            if(dots == true){

              for(int i=0; i<z.length;i++){
                  z[i] = new Complex(400*Math.random(),400*Math.random());
              }  
        
            }
//       boolean line = Line.inside(J.X);
//       if(line == true){
//           drawline = true;
//       }

        repaint();

    }

    public void mouseReleased(MouseEvent e) {
    }

    public void keyTyped(KeyEvent e) {
    }

    public void keyPressed(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }

    public void setSize(int width, int height) {
        super.setSize(width, height);
        draw.setSize(width, height);
    }

}
