package convex.polygon;

import java.applet.Applet;
import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.geom.*;
import java.math.*;
import java.util.*;
import java.util.Random;

public class ControlCanvas extends Canvas implements MouseListener, MouseMotionListener, KeyListener {

ListenSquare Control, Polygon1, Add1, Delete1,Vertices;
ListenSquare Polygon2, Add2, Delete2, Intersection;
PolygonWrapper P1,P2;
DrawMe draw;
Complex SOURCE ;
PolyChange I;
Graphics2D g3;

    public ControlCanvas(){
        addMouseListener(this);
	addMouseMotionListener(this);
	addKeyListener(this);
        Control=new ListenSquare(0,0,400,70);
        Polygon1=new ListenSquare(0,0,80,35);
        Add1=new ListenSquare(100,0,80,35);
        Delete1=new ListenSquare(200,0,80,35);
        Vertices=new ListenSquare(300,0,100,35);
        Intersection=new ListenSquare(300,35,100,35);
        Polygon2=new ListenSquare(0,35,80,35);
        Add2=new ListenSquare(100,35,80,35);
        Delete2=new ListenSquare(200,35,80,35);
        
        P1=new PolygonWrapper();
        P1.count=3;
        P1.z[0]=new Complex(20,200);
        P1.z[1]=new Complex(120,120);
        P1.z[2]=new Complex(20,120);
        
        
        P2=new PolygonWrapper();
        P2.count=3;
        P2.z[0]=new Complex(120,120);
        P2.z[1]=new Complex(20,200);
        P2.z[2]=new Complex(120,200);
        draw=new DrawMe();
        
    }
    
    private boolean displayDots = false;
    
      public void paint(Graphics g2) {    
      Graphics2D g=(Graphics2D) g2;
      g3=g;
      g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
      draw.drawBg(g,Control, Polygon1,Add1,Delete1,Intersection,Polygon2,Add2,Delete2,Vertices);    
      draw.drawPolygon1(g,P1);    
      draw.drawPolygon2(g,P2);
      if(displayDots) PolyChange.Dots(P1,P2,g);
     }
     
     public void mouseEntered(MouseEvent e) {}
     public void mouseExited(MouseEvent e) {}   
     public void mouseMoved(MouseEvent e) {}    
     public void mousePressed(MouseEvent e) {
    }

     
         public void mouseDragged(MouseEvent e) {
       MouseData J=MouseData.process(e);
       SOURCE=new Complex(J.X.x,J.X.y);
       PolygonWrapper P = new PolygonWrapper();
       boolean test=Control.inside(J.X);
       boolean test1=Polygon1.inside(J.X);

       if(test==false) {       
           P1=PolyChange.changePolygonf(P1,SOURCE);                         
       }
     
       
       repaint();
       
    }
     
          public void mouseClicked(MouseEvent e) {
        MouseData J=MouseData.process(e);
    
        boolean test2=Add1.inside(J.X);
        boolean test3=Delete1.inside(J.X);
        boolean test4=Polygon2.inside(J.X);
        boolean test5=Add2.inside(J.X);
        boolean test6=Delete2.inside(J.X);
        boolean test7=Intersection.inside(J.X);
        boolean test8=Vertices.inside(J.X);
        
        SOURCE=new Complex(J.X.x,J.X.y);
        PolygonWrapper P = new PolygonWrapper();
       
        if(test2==true)  {
            P1 = PolyChange.addPoint(P1);
        }
              
       
       if(test4==true) {
               P=P1; 
               P1=P2;
               P2=P;
           } 
       
        if(test3==true)  P1=PolyChange.deletePoint(P1);
        if(test5==true)  P2=PolyChange.addPoint(P2);
        if(test6==true)  P2=PolyChange.deletePoint(P2);
        if(test7==true)  {
            P1=PolyChange.interPoly(P1, P2);
            P2=P1;
        }
       
        if(test8==true) displayDots = !displayDots;
       
              repaint();
             
      
    }
          
    public void mouseReleased(MouseEvent e) {}

    public void keyTyped(KeyEvent e) {}
    public void keyPressed(KeyEvent e) {}
    public void keyReleased(KeyEvent e) {}
    
      public void setSize(int width, int height){
        super.setSize(width,height);
        draw.setSize(width,height);
    }

}
