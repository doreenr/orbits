package convex.polygon;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.awt.geom.*;
import java.math.*;


public class DrawMe extends Canvas {
    
      public void drawBg(Graphics2D g, ListenSquare Control, ListenSquare Polygon1, ListenSquare Add1, ListenSquare Delete1, ListenSquare Intersection, ListenSquare Polygon2, ListenSquare Add2, ListenSquare Delete2, ListenSquare Vertices) {
        g.setColor(Color.black);
        g.fillRect(0,0,getWidth(),getHeight());
        
        Control.render(g,new Color(0,0,100));
        Polygon1.render(g,Color.orange);
        Add1.render(g,Color.orange);
        Delete1.render(g,Color.orange);
        Vertices.render(g,Color.red);
        Intersection.render(g,Color.red);
        Polygon2.render(g,Color.pink);  
        Add2.render(g,Color.pink);
        Delete2.render(g,Color.pink);
        g.setColor(Color.white);
        g.drawString("polygon1",5,25);
        g.drawString("+ pts",105,25);
        g.drawString("- pts",210,25);
        g.drawString("Intersection",315,60);
        g.drawString("polygon2",5,60);
        g.drawString("+ pts",105,60);
        g.drawString("-pts",210,60);
        g.drawString("Vertices", 315, 25);
    }


    public void drawPolygon1(Graphics2D g, PolygonWrapper P1) {
       GeneralPath gp=P1.toGeneralPath();
       g.setColor(Color.orange);
       g.fill(gp);
       g.setColor(Color.orange);
       g.draw(gp);
    }

  
    public void drawPolygon2(Graphics2D g, PolygonWrapper P2) {
       GeneralPath gp=P2.toGeneralPath();
       g.setColor(Color.gray);
       //g.fill(gp);
       g.setColor(Color.gray);
       g.draw(gp);
    }
   
    public static void drawDots(Graphics2D g, Complex z){
        double x1=z.x;
        double y1=z.y;
        Ellipse2D.Double circle=new Ellipse2D.Double(x1,y1,5,5);
        g.setColor(Color.red);
        g.fill(circle);
     }
    
    public static void addVertex(Graphics2D g, Complex[] w){
      if(w.length > 3){ 
        for(int i=0; i < w.length; i++){
        Ellipse2D.Double circle=new Ellipse2D.Double(w[i].x, w[i].y, 5, 5);
        g.setColor(Color.green);
        g.fill(circle);    
        }
       }
      
    }
}
