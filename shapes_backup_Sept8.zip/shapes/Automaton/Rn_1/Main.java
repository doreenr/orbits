package convex.polygon;

import java.applet.Applet;
import java.awt.*;
import java.applet.*;
import java.math.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.io.*;
import java.util.*;


public class Main extends Applet {
    ControlCanvas C;

    public static void main(String[] args) {  
        Main a=new Main();
        Frame2 F=new Frame2("O=E",a);
	a.setBackground(new Color(100,0,0));
                  a.init();
	F.add(a);
	F.pack();
	F.addWindowListener(new WinList(F));
	F.setVisible(true);
    }


    public  void init() {   

	C=new ControlCanvas();
	add(C);
	C.setSize(400,400);
    } 

    public static class Frame2 extends Frame implements ComponentListener {
        Main a;

        public Frame2(String W,Main a) {
            super(W);
            this.a=a;
            addComponentListener(this);
        }


        public void componentHidden(ComponentEvent e) {
        }
        
        public void componentMoved(ComponentEvent e) {
        }
        
        public void componentResized(ComponentEvent e) {
	    a.C.setSize(getWidth(),getHeight());
	}

        public void componentShown(ComponentEvent e) {
        }
        
    }

    
}

