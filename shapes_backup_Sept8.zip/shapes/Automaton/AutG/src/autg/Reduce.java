/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autg;


/**
 *
 * @author Doreen
 */

class Reduce {
    public static int main(int args) {
        int m = args;
        int n = 0;
        if (m == 6) {
        } else if (m == 0) {
          n = 5;
        } else if (m == 7) {
          n = 2;
        } else if (m == -1) {
          n = 4;
        } else {
          n = m;
        }
        return n;
    }
}
                
    
