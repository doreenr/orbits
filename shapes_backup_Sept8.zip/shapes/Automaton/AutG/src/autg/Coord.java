/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autg;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Doreen
 */
public class Coord {
    private static Complex[] z = randomCoords(5);
    private static Complex[] c = randomCoordsCircle(5);

    Complex[] pi2;  
    
    public Coord() {}
    
    // call from both canvases
    public static Complex[] getInstance(int a) {
        if (a == 0){
            return z;
        }
        else {
        return c;
        }
    }
    
    public static Complex[] getnewInstance() {
        return c;
    }
    
    private static Complex[] randomCoords(int n) {
        final Complex[] results = new Complex[n];
        for(int i = 0; i < results.length; i++){         
            results[i] = new Complex(200 * Math.random(), 200 * Math.random());            
        }         
        return results;    
    }
    
    private static Complex[] randomCoordsCircle(int n) {
        final Complex[] pi2 = new Complex[n];
        double pi1, x, y;
        ArrayList<Double> pilist = new ArrayList();
        for(int i=0; i < pi2.length; i++) {
            pi1 = 2 * Math.PI * Math.random();
            pilist.add(pi1);
        }
        Collections.sort(pilist);        
        for (int i = 0; i < n; i++) {
            x = 100 + (40.0 * Math.cos(pilist.get(i))); // 100 = w/2
            y = 100 + (40.0 * Math.sin(pilist.get(i))); // 100 = h/2
            pi2[i] = new Complex(x,y);
        }
        return pi2;
    }
    
    // Creates n random vertices
    public Complex[] randCoord(Complex[] a) {
        // Complex[] z;
        // z = new Complex[n];
        for(int i = 0; i < a.length; i++){
            z[i] = new Complex(200*Math.random(),200*Math.random());
            }
        return z;
    }
    
    // Creates a random convex n-gon with vertices on a circle
    public Complex[] randCoordCircle(int n, String size) {
        pi2 = new Complex[n];
        double pi1, x, y;
        ArrayList<Double> pilist = new ArrayList();
        for(int i=0; i < pi2.length; i++) {
            pi1 = 2 * Math.PI * Math.random();
            pilist.add(pi1);
        }
        Collections.sort(pilist);  
        
        int s = 50;
        if (size == "small") {
            s = 10;
        }
        else {
        }
        
        for (int i = 0; i < n; i++) {
            x = 100 + (s * Math.cos(pilist.get(i))); // 100 = w/2
            y = 100 + (s * Math.sin(pilist.get(i))); // 100 = h/2
            pi2[i] = new Complex(x,y);
        }
        return pi2;
    }
     

    public static Complex[] staticCoord() {
        return z;
        }
    
}
    
