/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autg;
import java.util.Random;
/**
 *
 * @author Doreen
 */
public class RandGen {
    
    private static RandGen rando = null;
    private double r;
    
    private RandGen() {
        r = Math.random();
    }
    
    public static synchronized RandGen getInstance() {
        if (rando == null) {
            rando = new RandGen();
        }
        return rando;
    }
    
}
