/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autg;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.AffineTransform;


public class CanvasOrb extends Canvas implements MouseListener, MouseMotionListener, KeyListener {

    Graphics2D g3;
    Zeichnen zeichne;
    int h, w;

    public CanvasOrb() {
        addMouseListener(this);
        addMouseMotionListener(this);
        addKeyListener(this);
            
        }
    
    

    public void paint(Graphics g2) {
        zeichne = new Zeichnen();
        Graphics2D g = (Graphics2D) g2;
        g3 = g;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        h = getSize().height;
	w = getSize().width; 
        System.out.println(h +" ORB "+ w);
        zeichne.Orbit(g);
        /*
        AffineTransform at1 = new AffineTransform();
        at1.translate(w/2, h/2);
        g.transform(at1);*/

    }
    
        
               
    

    public void mouseEntered(MouseEvent e) {
    }

    public void mouseExited(MouseEvent e) {
    }

    public void mouseMoved(MouseEvent e) {
    }

    public void mousePressed(MouseEvent e) {
    }

    public void mouseDragged(MouseEvent e) {


    }

    public void mouseClicked(MouseEvent e) {
  

    }

    public void mouseReleased(MouseEvent e) {
    }

    public void keyTyped(KeyEvent e) {
    }

    public void keyPressed(KeyEvent e) {
    }

    public void keyReleased(KeyEvent e) {
    }

    public void setSize(int width, int height) {
        super.setSize(width, height);
        // g3.setSize(width, height);
    }

}
