/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autg;

import java.awt.*;
import java.awt.geom.Ellipse2D;


public class CanvasPI extends Canvas {

    // public Complex[] pi; 
    Graphics2D g3;
    Zeichnen zeichne;
    Complex[] z;
    int h, w;
    // private AutModel model;
    
    public CanvasPI() {
    }
    
    @Override
    public void paint(Graphics g2) {
        zeichne = new Zeichnen();
        Graphics2D g = (Graphics2D) g2;
        g3 = g;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        h = getSize().height;
	w = getSize().width; 
               
        Complex[] pi = new Complex[5];
        // pi = new Coord().getInstance(1);
        pi = new Coord().randCoordCircle(5, "normal");

        for(int i=0; i < pi.length; i++){
            zeichne.ExtLine(g, pi[i], pi[(i+1) % pi.length]);
        } 
        
    }

    public void setSize(int width, int height) {
        super.setSize(width, height);
        // g3.setSize(width, height);
    }

}
