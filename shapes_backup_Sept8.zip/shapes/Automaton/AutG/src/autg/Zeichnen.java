/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autg;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

/**
 *
 * @author Doreen
 */
public class Zeichnen {
    
    private AlphaComposite makeComposite(float alpha) {
        int type = AlphaComposite.SRC_OVER;
        return(AlphaComposite.getInstance(type, alpha));
    }
    
     public void Dot(Graphics2D g3, Complex z){
        double x1 = z.x;
        double y1 = z.y;
        float alpha = 0.5F;
        Ellipse2D.Double circle = new Ellipse2D.Double(x1,y1,5,5);
        g3.setColor(Color.black);
        g3.fill(circle);
     }
     
     public void Line(Graphics2D g, Complex p, Complex q){
       g.setColor(Color.black);
       float alpha = 0.5F;
       g.draw(new Line2D.Double(p.x,p.y,q.x,q.y));
    }
     public void ExtLine(Graphics2D g, Complex p, Complex q){
       double slope, y3, y4;
       // solve point slope form for x3 = 1000 and x4 = -1000
       slope = (q.y - p.y)/(q.x - p.x);
       y3 = (slope * (1000 - p.x)) + p.y;
       y4 = (slope * (-1000 - p.x)) + p.y;
       // System.out.println(p.x + ", p.y  " + p.y + ", q.x  "+ q.x +", q.y  "+ q.y);
       g.setColor(Color.LIGHT_GRAY);
       g.draw(new Line2D.Double(p.x, p.y, 1000, y3));
       g.draw(new Line2D.Double(p.x, p.y, -1000, y4));
       g.setColor(Color.black);
       Line2D line = new Line2D.Double(p.x,p.y,q.x,q.y);
       g.draw(line);

    }
     
     public void Orbit(Graphics2D g){
        float alpha = 0.5F;
        // Construct Matrix        
        Matrix Mx = new Matrix(5,200);
        Mx.element[1][0] = 2;
        Mx.element[1][1] = 3;
        Mx.element[1][2] = 1;
        Mx.element[1][3] = 9;
        Mx.element[1][4] = 8;
        Matrix My = new Matrix(5,200);
        My.element[1][0] = 3;
        My.element[1][1] = 4;
        My.element[1][2] = 2;
        My.element[1][3] = 7;
        My.element[1][4] = 3;
              
        double xtemp[] = Mx.element[1];
        double ytemp[] = My.element[1]; 
        double dx[] = Mx.element[1];
        double dy[] = My.element[1]; 
        
        for (int k = 0; k < Mx.columns; k++){
            for (int i = 0; i < Mx.rows; i++){
                int j1 = Reduce.main(i-1);
                // double max1 = Math.max(0, xtemp[(i-1) % Mx.rows]+ytemp[(i-1) % Mx.rows]);
                // CHECK BERECHNUNG
                double max2 = Math.max(0, xtemp[(i+1) % Mx.rows]+ytemp[(i+1) % Mx.rows]);
                double max3 = Math.max(0, xtemp[j1-1]+ytemp[j1-1]);
                dx[i] = dx[i] + max3 - max2;
                double max4 = Math.max(0, xtemp[(i+2) % Mx.rows] + ytemp[(i+2) % Mx.rows]);
                double max5 = Math.max(0, xtemp[i] + ytemp[i]);
                dy[i] = dy[(i+1) % Mx.rows] + max4 - max5;
                
                Ellipse2D.Double circle = new Ellipse2D.Double(dx[i],dy[i],5,5);
                g.setColor(Color.black);
                g.fill(circle);
                g.setComposite(makeComposite(alpha));
                
                }
        }
               
     }
}

