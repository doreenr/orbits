/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autg;

import java.awt.*;


public class CanvasRP extends Canvas {
    
    Graphics2D g3;
    Zeichnen zeichne;
    int h, w;
    Complex[] pi = new Complex[5];

    public CanvasRP() {
    }
    
    
    @Override
    public void paint(Graphics g2) {
        zeichne = new Zeichnen();
        Graphics2D g = (Graphics2D) g2;
        g3 = g;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        h = getSize().height;
	w = getSize().width; 
        pi = new Coord().randCoordCircle(5, "small");
        for(int i=0; i < pi.length; i++){
            zeichne.ExtLine(g, pi[i], pi[(i+1) % pi.length]);
        }         
    }
    
    public void setSize(int width, int height) {
        super.setSize(width, height);
        // g3.setSize(width, height);
    }
    


}