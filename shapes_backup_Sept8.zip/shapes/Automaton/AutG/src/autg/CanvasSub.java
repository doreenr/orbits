/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autg;

import java.awt.*;

public class CanvasSub extends CanvasPI {

    public CanvasSub() {}
    
    // @Override
    public void paint(Graphics g2) {
        zeichne = new Zeichnen();
        Graphics2D g = (Graphics2D) g2;
        g3 = g;
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        Complex[] perk = new Coord().randCoordCircle(5, "small");
            for(int i=0; i < perk.length; i++){
            zeichne.ExtLine(g, perk[i], perk[(i+1) % perk.length]);
            }
    }

    public void setSize(int width, int height) {
        super.setSize(width, height);
        // g3.setSize(width, height);
    }
    


}