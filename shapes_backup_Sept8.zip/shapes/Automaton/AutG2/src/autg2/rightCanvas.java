/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autg2;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Doreen
 */
public class rightCanvas extends Canvas {
	// Every left canvas has a random colored box in it
	// every time it is repainted, it is generated and painted
	
	int h, w;			// the height and width of this canvas
	
	public void paint(Graphics win) {
		int boxSize;
		int r, g, b;
		int x, y;
		
		// set the height and width of this canvas
		// this depends on where it is added, so we'll use
		// getSize to get its dimensions
		h = getSize().height;
		w = getSize().width;
		win.drawRect(0,0, w-1, h-1);		// Draw border
		
		// draw a random colored box
		boxSize = (int) (Math.random()*(w/4));
		x = (int) (Math.random()*w);
		y = (int) (Math.random()*h);
		
		r = (int) (Math.random()*256);
		g = (int) (Math.random()*256);
		b = (int) (Math.random()*256);
		
		win.setColor(new Color(r, g, b));
		win.fillRect(x, y, boxSize, boxSize);
		
	} // paint

} // leftCanvas
