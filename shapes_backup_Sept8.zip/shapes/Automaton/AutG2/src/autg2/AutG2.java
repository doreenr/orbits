/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package autg2;

/**
 *
 * @author Doreen
 */
import java.awt.*;
import java.applet.Applet;
import java.awt.event.*;

public class AutG2 extends Applet implements ActionListener {

	// GUI Widgets
	Button goButton;
	leftCanvas L;
	rightCanvas R;
	
	public void init() {
	
		setLayout(new BorderLayout());
		goButton = new Button("Do it again!");
		Panel bPanel = new Panel();
		bPanel.add(goButton);
		add("South", bPanel);
		goButton.addActionListener(this);
		
		// add the two canvases
		Panel centerPanel = new Panel();
		centerPanel.setLayout(new GridLayout(1,2));
		L = new leftCanvas();
		R = new rightCanvas();
		centerPanel.add(L);
		centerPanel.add(R);
		add("Center", centerPanel);
	} // init
	
	public void actionPerformed(ActionEvent e) {
	
		if (e.getSource() == goButton) {
			repaint();		// repaint this applet
			L.repaint();	// also repaint the canvases
			R.repaint();	// repaint canvases
		}
			
	} // actionPerformed

} // AutG2



